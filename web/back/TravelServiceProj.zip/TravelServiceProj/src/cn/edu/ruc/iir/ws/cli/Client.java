
package cn.edu.ruc.iir.ws.cli;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import cn.edu.ruc.iir.ws.controller.UserController;

public class Client {
	public static void main(String[] args) throws Exception {
		QName serviceName = new QName("http://localhost/", "UserService");
		QName portName = new QName("http://localhost/", "UserPort");

		String addr = "http://localhost:8080/Tutorial-on-BPEL/getUser?wsdl";
		URL url = new URL(addr);

		Service service = Service.create(url, serviceName);
		UserController userController = service.getPort(portName, UserController.class);

		String uname = "taoyouxian";
		String res = userController.getUser(uname);

		System.out.println("res:" + res);

	}
}
