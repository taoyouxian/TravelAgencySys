
package cn.edu.ruc.iir.ws.client.service;

import java.rmi.RemoteException;

import javax.servlet.http.HttpServletRequest;

import org.apache.axis2.AxisFault;

import cn.edu.ruc.iir.ws.client.service.impl.GetTour;
import cn.edu.ruc.iir.ws.client.service.impl.GetTourResponse;
import cn.edu.ruc.iir.ws.client.service.impl.GetTourist;
import cn.edu.ruc.iir.ws.client.service.impl.GetTouristResponse;
import cn.edu.ruc.iir.ws.client.service.impl.TourServiceI;
import cn.edu.ruc.iir.ws.client.service.impl.TourServiceIStub;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceI;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceIStub;

public class WSDLService {

	private static WSDLService instance = null;

	public static WSDLService getInstance() {
		if (instance == null) {
			instance = new WSDLService();
		}
		return instance;
	}

	public String getTourist(HttpServletRequest request) {
		TouristServiceI tService = null;
		try {
			tService = new TouristServiceIStub();
		} catch (AxisFault e) {

			e.printStackTrace();

		}
		GetTourist g = new GetTourist();
		GetTouristResponse response = null;
		try {
			response = tService.getTourist(g);
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		String res = response.get_return();
		return res;
	}

	public String getTour(HttpServletRequest request) throws RemoteException {
		TourServiceI tService = new TourServiceIStub();

		GetTour g = new GetTour();
		// String f_day_btime = "2018-01-04";
		// String f_start_addr = "北京";
		// String f_arrive_addr = "南京";
		// int p_days = 3;
		// int p_budget = 5200;
		String f_day_btime = request.getParameter("f_day_btime");
		String f_start_addr = request.getParameter("f_start_addr");
		String f_arrive_addr = request.getParameter("f_arrive_addr");
		int p_days = Integer.valueOf(request.getParameter("p_days"));
		int p_budget = Integer.valueOf(request.getParameter("p_budget"));
		g.setF_start_addr(f_start_addr);
		g.setF_arrive_addr(f_arrive_addr);
		g.setF_day_btime(f_day_btime);
		g.setP_days(p_days);
		g.setP_budget(p_budget);

		GetTourResponse response = tService.getTour(g);

		String res = response.get_return();
		return res;
	}

}
