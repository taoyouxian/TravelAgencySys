

/**
 * TourServiceI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.6  Built on : Jul 30, 2017 (09:08:31 BST)
 */

    package cn.edu.ruc.iir.ws.client.service.impl;

    /*
     *  TourServiceI java interface
     */

    public interface TourServiceI {
          

        /**
          * Auto generated method signature
          * 
                    * @param getTour0
                
         */

         
                     public cn.edu.ruc.iir.ws.client.service.impl.GetTourResponse getTour(

                        cn.edu.ruc.iir.ws.client.service.impl.GetTour getTour0)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param getTour0
            
          */
        public void startgetTour(

            cn.edu.ruc.iir.ws.client.service.impl.GetTour getTour0,

            final cn.edu.ruc.iir.ws.client.service.impl.TourServiceICallbackHandler callback)

            throws java.rmi.RemoteException;

     

        
       //
       }
    