package cn.edu.ruc.iir.ws.client.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class TourServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(TourServiceImlp.class);

	public String getTour(String f_day_btime, String f_start_addr, String f_arrive_addr, int p_days, int p_budget) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("f_day_btime", f_day_btime);
		aPs.put("f_start_addr", f_start_addr);
		aPs.put("f_arrive_addr", f_arrive_addr);
		aPs.put("p_days", String.valueOf(p_days));
		aPs.put("p_budget", String.valueOf(p_budget));
		String fileName = "client/Recommend/getTour.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		JSONArray aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getTourist: " + res);
		return res;
	}

}
