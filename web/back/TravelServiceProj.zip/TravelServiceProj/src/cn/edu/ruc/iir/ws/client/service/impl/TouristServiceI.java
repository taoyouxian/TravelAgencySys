

/**
 * TouristServiceI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.6  Built on : Jul 30, 2017 (09:08:31 BST)
 */

    package cn.edu.ruc.iir.ws.client.service.impl;

    /*
     *  TouristServiceI java interface
     */

    public interface TouristServiceI {
          

        /**
          * Auto generated method signature
          * 
                    * @param getTourist0
                
         */

         
                     public cn.edu.ruc.iir.ws.client.service.impl.GetTouristResponse getTourist(

                        cn.edu.ruc.iir.ws.client.service.impl.GetTourist getTourist0)
                        throws java.rmi.RemoteException
             ;

        
         /**
            * Auto generated method signature for Asynchronous Invocations
            * 
                * @param getTourist0
            
          */
        public void startgetTourist(

            cn.edu.ruc.iir.ws.client.service.impl.GetTourist getTourist0,

            final cn.edu.ruc.iir.ws.client.service.impl.TouristServiceICallbackHandler callback)

            throws java.rmi.RemoteException;

     

        
       //
       }
    