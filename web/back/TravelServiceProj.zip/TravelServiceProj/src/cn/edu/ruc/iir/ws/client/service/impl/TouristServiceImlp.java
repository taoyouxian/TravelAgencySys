package cn.edu.ruc.iir.ws.client.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class TouristServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(TouristServiceImlp.class);

	public String getTourist() {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		// aPs.put("", "");
		String fileName = "client/Friend/GetTourist.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		JSONArray aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getTourist: " + res);
		return res;
	}

}
