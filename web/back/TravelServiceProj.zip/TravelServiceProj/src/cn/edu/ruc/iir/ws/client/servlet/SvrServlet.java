package cn.edu.ruc.iir.ws.client.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import cn.edu.ruc.iir.ws.client.service.WSDLService;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceImlp;

/**
 * Servlet implementation class SvrServlet
 */
@WebServlet(description = "前台业务逻辑部分", urlPatterns = { "/WSDLSvr" })
public class SvrServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(SvrServlet.class.getName());

	WSDLService wService = WSDLService.getInstance();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SvrServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 跨域请求
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 跨域请求
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 将请求、响应的编码均设置为UTF-8(防止中文乱码)
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String aJson = "";
		try {
			String aAction = request.getParameter("Action");
			try {
				switch (aAction) {
				case "getTourist":
					aJson = wService.getTourist(request);
					break;
				case "getTour":
					aJson = wService.getTour(request);
					break;
				}
			} catch (Exception e) {
				log.info(e.getMessage());
			}
			super.writeJson(aJson, response);
		} catch (Exception e) {
			log.info(e.getMessage());
		}

	}

}
