package cn.edu.ruc.iir.ws.dao;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONArray;

import cn.edu.ruc.iir.ws.model.PageTable;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.JsonDBUtil;

public class DBDao {
	private static Logger log = Logger.getLogger(DBDao.class.getName());

	static DBDao _tDB = null;
	static DBUtils dbUtils = null;

	public static DBDao geTiDB() {
		if (_tDB == null) {
			_tDB = new DBDao();
			dbUtils = DBUtils.Instance();
		}
		return _tDB;
	}

	// 执行SQL操作
	public boolean executeSql(String aSql) {
		boolean aFlag = false;
		try {
			aFlag = dbUtils.Execute(aSql);
		} catch (Exception er) {
			log.info(er.getMessage());
		}
		return aFlag;
	}

	// 执行SQL文件及参数表的SQL操作
	public boolean executeSql(String aSql, Map<String, String> aPs) {
		String sql = dbUtils.getSQL(aSql, aPs);
		return executeSql(sql);
	}

	public JSONArray getTable(String aSql) {
		JSONArray aDBJson = null;
		try {
			ResultSet rs = dbUtils.Select(aSql);
			aDBJson = JsonDBUtil.rSToJson(rs);
		} catch (Exception er) {
			log.info(er.getMessage());
		}
		return aDBJson;
	}

	// 根据文件名与参数表返回查询结果
	public JSONArray getTable(String aSql, Map<String, String> aPs, List<String> aErrors) {
		String sql = dbUtils.getSQL(aSql, aPs);
		return getTable(sql);
	}

	public Object acGetPageTable(String sql, String aOrderFields, String aPageSize, String aPageIndex) {
		PageTable aRes = new PageTable();
		ResultSet rs = null;
		try {
			aRes.PageSize = Integer.valueOf(aPageSize);
			aRes.OrderFields = aOrderFields;
			String aRowCountSql = "Select COUNT(*) as F_RowCount from ( " + sql + " ) a";
			log.info("aRowCountSql: " + aRowCountSql);
			try {
				rs = dbUtils.Select(aRowCountSql);
				rs.next();
				aRes.RowCount = rs.getInt("F_RowCount");
			} catch (Exception e) {
			}
			if (aRes.RowCount == 0) {

			} else {
				aRes.PageCount = (int) Math.ceil(aRes.RowCount * 1.0 / aRes.PageSize);
				aRes.PageIndex = Integer.valueOf(aPageIndex);
				aRes.PageIndex = aRes.PageIndex > aRes.PageCount ? aRes.PageCount : aRes.PageIndex;
				aRes.PageIndex = aRes.PageIndex < 1 ? 1 : aRes.PageIndex;
				String aDataSql = "Select * from (	Select ROW_NUMBER() over (order By [OrderFields]) as F_RowNumber , a.* from ( [SrcSql]) a) s where F_RowNumber<= [PageIndex] * [PageSize] and F_RowNumber> ([PageIndex]-1)*[PageSize]";
				aDataSql = aDataSql.replace("[SrcSql]", sql);
				aDataSql = aDataSql.replace("[OrderFields]", aOrderFields);
				aDataSql = aDataSql.replace("[PageSize]", String.valueOf(aRes.PageSize));
				aDataSql = aDataSql.replace("[PageIndex]", String.valueOf(aRes.PageIndex));
				log.info("pageTableSql: " + aDataSql);
				rs = dbUtils.Select(aDataSql);
				aRes.Datajson = JsonDBUtil.rSetToJson(rs);
			}

		} catch (Exception er) {
			log.info(er.getMessage());
		}
		return aRes;
	}

}
