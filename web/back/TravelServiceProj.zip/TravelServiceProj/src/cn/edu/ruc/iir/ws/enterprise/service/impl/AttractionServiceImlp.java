package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class AttractionServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(AttractionServiceImlp.class);

	public String getAttraction(String aOrderFields, String aPageSize, String aPageIndex, String aSqlPs) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("aOrderFields", aOrderFields);
		aPs.put("aPageSize", aPageSize);
		aPs.put("aPageIndex", aPageIndex);
		aPs.put("aSqlPs", aSqlPs);
		String fileName = "enterprise/Attraction/Attractions.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.acGetPageTable(sql, aOrderFields, aPageSize, aPageIndex);
		String res = JSON.toJSONString(aJson);
		log.debug("getAttraction: " + res);
		return res;
	}

	public String NewAttraction(String a_location, String a_tour_type, String a_tour) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("a_location", a_location);
		aPs.put("a_tour_type", a_tour_type);
		aPs.put("a_tour", a_tour);
		String fileName = "enterprise/Attraction/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getAttraction: " + res);
		return res;
	}

	public String EditAttraction(String a_location, String a_tour_type, String a_tour, String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("a_location", a_location);
		aPs.put("a_tour_type", a_tour_type);
		aPs.put("a_tour", a_tour);
		aPs.put("id", id);
		String fileName = "enterprise/Attraction/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getAttraction: " + res);
		return res;
	}

	public String DeleteAttraction(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Attraction/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getAttraction: " + res);
		return res;
	}
}
