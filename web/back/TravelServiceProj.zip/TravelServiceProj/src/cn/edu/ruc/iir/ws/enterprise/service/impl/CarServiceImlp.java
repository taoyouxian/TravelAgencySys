package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class CarServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(CarServiceImlp.class);

	public String getCar(String aOrderFields, String aPageSize, String aPageIndex, String aSqlPs) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("aOrderFields", aOrderFields);
		aPs.put("aPageSize", aPageSize);
		aPs.put("aPageIndex", aPageIndex);
		aPs.put("aSqlPs", aSqlPs);
		String fileName = "enterprise/Car/Cars.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.acGetPageTable(sql, aOrderFields, aPageSize, aPageIndex);
		String res = JSON.toJSONString(aJson);
		log.debug("getCar: " + res);
		return res;
	}

	public String NewCar(String c_lease_addr, String c_return_addr, String c_lease_time, String c_return_time,
			String c_recommend_com, String c_s_id, String c_pre_id, String c_pri_id, String c_ty_id, String c_tr_id,
			String c_daily_price) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("c_lease_addr", c_lease_addr);
		aPs.put("c_return_addr", c_return_addr);
		aPs.put("c_lease_time", c_lease_time);
		aPs.put("c_return_time", c_return_time);
		aPs.put("c_recommend_com", c_recommend_com);
		aPs.put("c_s_id", c_s_id);
		aPs.put("c_pre_id", c_pre_id);
		aPs.put("c_pri_id", c_pri_id);
		aPs.put("c_ty_id", c_ty_id);
		aPs.put("c_tr_id", c_tr_id);
		aPs.put("c_daily_price", c_daily_price);
		String fileName = "enterprise/Car/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getCar: " + res);
		return res;
	}

	public String EditCar(String c_lease_addr, String c_return_addr, String c_lease_time, String c_return_time,
			String c_recommend_com, String c_s_id, String c_pre_id, String c_pri_id, String c_ty_id, String c_tr_id,
			String c_daily_price, String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("c_lease_addr", c_lease_addr);
		aPs.put("c_return_addr", c_return_addr);
		aPs.put("c_lease_time", c_lease_time);
		aPs.put("c_return_time", c_return_time);
		aPs.put("c_recommend_com", c_recommend_com);
		aPs.put("c_s_id", c_s_id);
		aPs.put("c_pre_id", c_pre_id);
		aPs.put("c_pri_id", c_pri_id);
		aPs.put("c_ty_id", c_ty_id);
		aPs.put("c_tr_id", c_tr_id);
		aPs.put("c_daily_price", c_daily_price);
		aPs.put("id", id);
		String fileName = "enterprise/Car/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getCar: " + res);
		return res;
	}

	public String DeleteCar(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Car/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getCar: " + res);
		return res;
	}
}
