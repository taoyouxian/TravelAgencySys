package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class FlightServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(FlightServiceImlp.class);

	public String getFlight(String aOrderFields, String aPageSize, String aPageIndex, String aSqlPs) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("aOrderFields", aOrderFields);
		aPs.put("aPageSize", aPageSize);
		aPs.put("aPageIndex", aPageIndex);
		aPs.put("aSqlPs", aSqlPs);
		String fileName = "enterprise/Flight/Flights.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.acGetPageTable(sql, aOrderFields, aPageSize, aPageIndex);
		String res = JSON.toJSONString(aJson);
		log.debug("getFlight: " + res);
		return res;
	}

	public String NewFlight(String f_code, String f_caption, String f_start_addr, String f_arrive_addr,
			String f_start_time, String f_arrive_time, String f_duration, String f_duration_info, String f_price) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("f_code", f_code);
		aPs.put("f_caption", f_caption);
		aPs.put("f_start_addr", f_start_addr);
		aPs.put("f_arrive_addr", f_arrive_addr);
		aPs.put("f_start_time", f_start_time);
		aPs.put("f_arrive_time", f_arrive_time);
		aPs.put("f_duration", f_duration);
		aPs.put("f_duration_info", f_duration_info);
		aPs.put("f_price", f_price);
		String fileName = "enterprise/Flight/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getFlight: " + res);
		return res;
	}

	public String EditFlight(String f_code, String f_caption, String f_start_addr, String f_arrive_addr,
			String f_start_time, String f_arrive_time, String f_duration, String f_duration_info, String f_price,
			String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("f_code", f_code);
		aPs.put("f_caption", f_caption);
		aPs.put("f_start_addr", f_start_addr);
		aPs.put("f_arrive_addr", f_arrive_addr);
		aPs.put("f_start_time", f_start_time);
		aPs.put("f_arrive_time", f_arrive_time);
		aPs.put("f_duration", f_duration);
		aPs.put("f_duration_info", f_duration_info);
		aPs.put("f_price", f_price);
		aPs.put("id", id);
		String fileName = "enterprise/Flight/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getFlight: " + res);
		return res;
	}

	public String DeleteFlight(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Flight/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getFlight: " + res);
		return res;
	}

}
