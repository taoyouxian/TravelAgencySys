package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class HotelServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(HotelServiceImlp.class);

	public String getHotel(String aOrderFields, String aPageSize, String aPageIndex, String aSqlPs) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("aOrderFields", aOrderFields);
		aPs.put("aPageSize", aPageSize);
		aPs.put("aPageIndex", aPageIndex);
		aPs.put("aSqlPs", aSqlPs);
		String fileName = "enterprise/Hotel/Hotels.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.acGetPageTable(sql, aOrderFields, aPageSize, aPageIndex);
		String res = JSON.toJSONString(aJson);
		log.debug("getHotel: " + res);
		return res;
	}

	public String NewHotel(String h_name, String h_code, String h_start_time, String h_end_time, String h_city,
			String h_t_id, String h_s_id, String h_p_id, String h_b_id, String h_a_id, String h_price) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("h_name", h_name);
		aPs.put("h_code", h_code);
		aPs.put("h_start_time", h_start_time);
		aPs.put("h_end_time", h_end_time);
		aPs.put("h_city", h_city);
		aPs.put("h_t_id", h_t_id);
		aPs.put("h_s_id", h_s_id);
		aPs.put("h_p_id", h_p_id);
		aPs.put("h_b_id", h_b_id);
		aPs.put("h_a_id", h_a_id);
		aPs.put("h_price", h_price);
		String fileName = "enterprise/Hotel/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getHotel: " + res);
		return res;
	}

	public String EditHotel(String h_name, String h_code, String h_start_time, String h_end_time, String h_city,
			String h_t_id, String h_s_id, String h_p_id, String h_b_id, String h_a_id, String h_price, String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("h_name", h_name);
		aPs.put("h_code", h_code);
		aPs.put("h_start_time", h_start_time);
		aPs.put("h_end_time", h_end_time);
		aPs.put("h_city", h_city);
		aPs.put("h_t_id", h_t_id);
		aPs.put("h_s_id", h_s_id);
		aPs.put("h_p_id", h_p_id);
		aPs.put("h_b_id", h_b_id);
		aPs.put("h_a_id", h_a_id);
		aPs.put("h_price", h_price);
		aPs.put("id", id);
		String fileName = "enterprise/Hotel/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getHotel: " + res);
		return res;
	}

	public String DeleteHotel(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Hotel/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getHotel: " + res);
		return res;
	}
}
