package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class RoomServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(RoomServiceImlp.class);

	public String getRoom(String hid) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("hid", hid);
		String fileName = "enterprise/Room/Rooms.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getRoom: " + res);
		return res;
	}

	public String NewRoom(String r_h_id, String h_code, String r_code, String r_type, String r_bed, String r_cancel,
			String r_eat, String r_wifi, String r_daily_price) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("r_h_id", r_h_id);
		aPs.put("h_code", h_code);
		aPs.put("r_code", r_code);
		aPs.put("r_type", r_type);
		aPs.put("r_bed", r_bed);
		aPs.put("r_cancel", r_cancel);
		aPs.put("r_eat", r_eat);
		aPs.put("r_wifi", r_wifi);
		aPs.put("r_daily_price", r_daily_price);
		String fileName = "enterprise/Room/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getRoom: " + res);
		return res;
	}

	public String EditRoom(String r_h_id, String h_code, String r_code, String r_type, String r_bed, String r_cancel,
			String r_eat, String r_wifi, String r_daily_price, String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("r_h_id", r_h_id);
		aPs.put("h_code", h_code);
		aPs.put("r_code", r_code);
		aPs.put("r_type", r_type);
		aPs.put("r_bed", r_bed);
		aPs.put("r_cancel", r_cancel);
		aPs.put("r_eat", r_eat);
		aPs.put("r_wifi", r_wifi);
		aPs.put("r_daily_price", r_daily_price);
		aPs.put("id", id);
		String fileName = "enterprise/Room/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getRoom: " + res);
		return res;
	}

	public String DeleteRoom(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Room/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getRoom: " + res);
		return res;
	}
}
