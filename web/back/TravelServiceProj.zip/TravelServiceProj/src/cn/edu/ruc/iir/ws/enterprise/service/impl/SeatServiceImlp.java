package cn.edu.ruc.iir.ws.enterprise.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;

import cn.edu.ruc.iir.ws.dao.DBDao;
import cn.edu.ruc.iir.ws.util.ConfigFactory;
import cn.edu.ruc.iir.ws.util.DBUtils;
import cn.edu.ruc.iir.ws.util.ReadSQLUtil;

public class SeatServiceImlp {

	ConfigFactory config = ConfigFactory.Instance();
	DBUtils dbUtils = DBUtils.Instance();
	DBDao dbDao = DBDao.geTiDB();

	private static Logger log = Logger.getLogger(SeatServiceImlp.class);

	public String getSeat(String hid) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("hid", hid);
		String fileName = "enterprise/Seat/Seats.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getSeat: " + res);
		return res;
	}

	public String NewSeat(String s_f_id, String s_num, String s_type, String s_daily_price) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("s_f_id", s_f_id);
		aPs.put("s_num", s_num);
		aPs.put("s_type", s_type);
		aPs.put("s_daily_price", s_daily_price);
		String fileName = "enterprise/Seat/New.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.getTable(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getSeat: " + res);
		return res;
	}

	public String EditSeat(String s_f_id, String s_num, String s_type, String s_daily_price, String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("s_f_id", s_f_id);
		aPs.put("s_num", s_num);
		aPs.put("s_type", s_type);
		aPs.put("s_daily_price", s_daily_price);
		aPs.put("id", id);
		String fileName = "enterprise/Seat/Edit.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getSeat: " + res);
		return res;
	}

	public String DeleteSeat(String id) {
		ReadSQLUtil.sqlSource = config.getProperty("SQLDirectory");
		Map<String, String> aPs = new HashMap<String, String>();
		aPs.put("id", id);
		String fileName = "enterprise/Seat/Delete.txt";
		String aSql = ReadSQLUtil.ReadSqlFile(fileName);
		String sql = dbUtils.getSQL(aSql, aPs);
		Object aJson = dbDao.executeSql(sql);
		String res = JSON.toJSONString(aJson);
		log.debug("getSeat: " + res);
		return res;
	}

}
