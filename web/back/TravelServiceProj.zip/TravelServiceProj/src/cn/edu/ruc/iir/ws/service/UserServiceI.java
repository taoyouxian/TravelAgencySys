
package cn.edu.ruc.iir.ws.service;

public interface UserServiceI {

	String getUser(String uname);

}
