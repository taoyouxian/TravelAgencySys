package ws.example.airline;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Provide airline service. Based on params, return recommended airlines;
 * @param dayGo: when to go
 * @param dayReturn: when to return
 * @param cityFrom: From which city
 * @param cityTo: Go to which city
 * @param prefE: economic or commercial seat
 * @param prefP: highest price
 * */
@WebService
public class AirlineService {
	// sql template
	private String sqlT = "select * from airline where";

	/**
	 * Return satisfied flight info.
	 * @param dayGo: Date(between 2016-06-01 and 2016-06-06)
	 * @param cityFrom: Start(Beijing, Shanghai, Guangzhou)
	 * @param cityTo: Destination(Beijing, Shanghai, Guangzhou)
	 * @param prefE: Economic or Commercial. Pass in 'E' or 'C' or ''
	 * @param prefP: Preferred highest price
	 * @return 'airline-prefE-price,airline-prefE-price'
	 * */
	@WebMethod(action="airlineQuery")
	public String getAirline(String dayGo, String cityFrom, String cityTo, String prefE, double prefP) {
		System.out.println("call getairline");
		String[] rStrings = new String[2];
		String rString;
		String sql = sqlT + " daygo = " + "'" + dayGo + "'" +
				" AND cityfrom = " + "'" + cityFrom + "'" +
				" AND cityto = " + "'" + cityTo + "'";
		if (prefE != "" && prefE != null) {
			sql += " AND pref = " + "'" + prefE + "'";
		}
		if (prefP != Double.NaN && prefP != 0.0) {
			sql +=" AND price <= " + prefP;
		}
		sql += " ORDER BY price LIMIT 2";
		
		try {
			DBConnection dbConnection = new DBConnection();
		    ResultSet rSet = dbConnection.runSql(sql);
		    int i = 0;
		    while (rSet.next()) {
		    	rString = rSet.getString("airline") + "-" 
		                        + rSet.getString("pref") + "-"
		                        + rSet.getDouble("price");
		    	rStrings[i] = rString;
		    	i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rStrings[0]+","+rStrings[1];
	}
	
	/**
	 * Return satisfied lowest flight price.
	 * @param dayGo: Date(between 2016-06-01 and 2016-06-06)
	 * @param cityFrom: Start(Beijing, Shanghai, Guangzhou)
	 * @param cityTo: Destination(Beijing, Shanghai, Guangzhou)
	 * @param prefE: Economic or Commercial. Pass in 'E' or 'C' or ''
	 * @param prefP: Preferred highest price
	 * @return price
	 * */
	@WebMethod(action="getTicketPrice")
	public double getTicketPrice(String dayGo, String cityFrom, String cityTo, String prefE, double prefP) {
		System.out.println("call getTicketPrice");
		double lowPrice = 0.0;
		String sql = sqlT + " daygo = " + "'" + dayGo + "'" +
				" AND cityfrom = " + "'" + cityFrom + "'" +
				" AND cityto = " + "'" + cityTo + "'";
		if (prefE != "" && prefE != null) {
			sql += " AND pref = " + "'" + prefE + "'";
		}
		if (prefP != Double.NaN && prefP != 0.0) {
			sql +=" AND price <= " + prefP;
		}
		sql += " ORDER BY price LIMIT 1";
		System.out.println(sql);
		try {
			DBConnection dbConnection = new DBConnection();
		    ResultSet rSet = dbConnection.runSql(sql);
		    while(rSet.next()) {
		    	lowPrice = rSet.getDouble("price");
		    	break;
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lowPrice;
	}
}
