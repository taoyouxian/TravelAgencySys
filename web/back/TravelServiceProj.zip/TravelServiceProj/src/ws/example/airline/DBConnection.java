package ws.example.airline;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBConnection {
	private String url = "jdbc:postgresql://10.77.30.213/mydb";
	private String user = "jelly";
	private String pass = "nhmr6080";
	private Properties props = new Properties();
	private Statement statement = null;
	
	private Connection conn;
	
	public DBConnection() throws SQLException {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		props.setProperty("user", user);
		props.setProperty("password", pass);
		conn = DriverManager.getConnection(url, props);
	}
	
	public ResultSet runSql(String query) {
		try {
			statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			conn.close();
			return resultSet;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
