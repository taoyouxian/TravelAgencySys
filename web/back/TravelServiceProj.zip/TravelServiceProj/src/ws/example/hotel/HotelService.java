package ws.example.hotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HotelService {
	
	/*public static void main( String[] args) {
		System.out.println( getHotel("2016-06-02","2016-06-03", "Beijing", 2000));
	}*/
	
	public Connection con=null;
	public Statement stmt = null;
	private void getConn(){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://222.29.196.133:3306/Hotel";
		String user = "root";
		String password = "123456";
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			stmt = con.createStatement();
		}catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	public String  getHotel(String  startDate, String endDate, String city, double price) {
		System.out.println("call getHotel");
		String[] hotels = new String[2];
		double per = 0;
		int days = Integer.parseInt(endDate.substring(endDate.length()-2,endDate.length())) - Integer.parseInt(startDate.substring(startDate.length()-2,startDate.length()));
		if(days!=0){
			per = price/days;
		}
		int count = 0;
		try{ 
			getConn();
	    	String sql = "select name from hotel_list where location='" + city+"' and start_time<='"+ startDate + "' and end_time>='"+ endDate + "' and price<='"+per+"' order by price desc";
			ResultSet rs = stmt.executeQuery(sql);
			//get 2 results
			while ( rs.next() && count++ < 2) {
				hotels[count -1] = rs.getString("name");
			}   
            con.close();
		} catch (SQLException e) {
            System.out.println("MySQL operation error!");
            e.printStackTrace();
        } 
		return hotels[0] +"," +hotels[1];
	} 
	
	public double  getHotelPrice(String  startDate, String endDate, String city, double price) {
		System.out.println("call getHotelPrice");
		double per = 0;
		int days = Integer.parseInt(endDate.substring(endDate.length()-2,endDate.length())) - Integer.parseInt(startDate.substring(startDate.length()-2,startDate.length()));
		if(days!=0){
			per = price/days;
		}
		double cost=0;
		try{ 
			getConn();
			String sql = "select price from hotel_list where location='" + city+"' and start_time<='"+ startDate + "' and end_time>='"+ endDate + "' and price<='"+per+"' order by price desc";
			ResultSet rs = stmt.executeQuery(sql);
			//get the price
			rs.next();
			cost = rs.getDouble("price") * days;
            con.close();
		} catch (SQLException e) {
            System.out.println("MySQL operation error!");
            e.printStackTrace();
        }
		return cost;
	}
}
