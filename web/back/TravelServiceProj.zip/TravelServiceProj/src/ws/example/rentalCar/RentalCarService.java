package ws.example.rentalCar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RentalCarService {
	
	/*public static void main( String[] args) {
		System.out.println(getRentalCar( "���ᳵ��","AT",
				"Guangzhou","Guangzhou","2016-06-04","2016-06-04","�ռ��"));
	}*/
	
	public String getRentalCar(String CarType,String MT_AT,String Dep_City,
			String Des_Ctiy,String StartUse_Date,String StopUse_Date,String Preference){
		System.out.println("call getRentalCar");
		String Serv_Com=""; //���ص��⳵����ID����ַ���
		
		//Connect the database and search the database
		PreparedStatement ps=null;
		Connection ct=null;
		ResultSet rs=null;
		String s1=null,s2=null,temp=null;
		double min = 0.0,max = 0.0,price=0.0;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url = "jdbc:sqlserver://10.77.30.233:1433; DatabaseName=car";
			ct=DriverManager.getConnection(url, "sa","123");
			System.out.println("Connect the database succssfully!");
			ps=ct.prepareStatement("select Serv_ID,Company,DailyPrice from car where CarType=? "
					+ "and MT_AT=? and Dep_City=? and Des_Ctiy=? and StopUse_Time<? "
					+ "and ReStart_Time>? and Preference=?");
			ps.setString(1,CarType);
			ps.setString(2,MT_AT);
			ps.setString(3,Dep_City);
			ps.setString(4,Des_Ctiy);
			ps.setString(5,StartUse_Date);
			ps.setString(6,StopUse_Date);
			ps.setString(7,Preference);
			rs=ps.executeQuery();
			while(rs.next()){
				String s=rs.getString(1)+"-"+rs.getString(2);
				price = Double.parseDouble(rs.getString(3));
				if(s1==null){
					s1=s;
					min=price;
					max=min;
				}
				else if(s1!=null && s2==null){
					s2=s;
					if(price > max){
						max = price;
					}
					else{
						temp=s1;
						s1=s2;
						s2=temp;
						max=min;
						min=price;
					}
				}
				else if(s1!=null&&s2!=null){
					if(price < max){
						if(price>min){
							s2=s;
							max=price;
						}
						else{
							s2=s1;
							s1=s;
							max=min;
							min=price;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		Serv_Com=s1+","+s2;
		//Return the lowest price
		//rent_Price(min);
		System.out.println(Serv_Com);
		return Serv_Com;
	}
	
	/***Return the lowest price***/ 
	public double getRentalCarPrice(String CarType,String MT_AT,String Dep_City,
			String Des_Ctiy,String StartUse_Date,String StopUse_Date,String Preference){
		System.out.println("call getRenatalCarPrice");
		//System.out.println(min);
		//return min;
		
		double min_price = 1000.0;
		//Connect the database and search the database
		PreparedStatement ps=null;
		Connection ct=null;
		ResultSet rs=null;
		String price=null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url = "jdbc:sqlserver://10.77.30.233:1433; DatabaseName=car";
			ct=DriverManager.getConnection(url, "sa","123");
			System.out.println("Connect the database succssfully!");
			ps=ct.prepareStatement("select Serv_ID,Company,DailyPrice from car where CarType=? "
					+ "and MT_AT=? and Dep_City=? and Des_Ctiy=? and StopUse_Time<? "
					+ "and ReStart_Time>? and Preference=?");
			ps.setString(1,CarType);
			ps.setString(2,MT_AT);
			ps.setString(3,Dep_City);
			ps.setString(4,Des_Ctiy);
			ps.setString(5,StartUse_Date);
			ps.setString(6,StopUse_Date);
			ps.setString(7,Preference);
			rs=ps.executeQuery();
			while(rs.next()){
				price = rs.getString(3);
				double temp = Double.parseDouble(price);
				if(temp < min_price){
					min_price = temp;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		//Return the lowest price
		System.out.println(min_price);
		return min_price;
	}
}
