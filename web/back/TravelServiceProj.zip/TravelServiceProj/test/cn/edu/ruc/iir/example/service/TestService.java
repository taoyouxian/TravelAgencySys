
package cn.edu.ruc.iir.example.service;

import java.rmi.RemoteException;

import org.apache.log4j.Logger;
import org.junit.Test;

import cn.edu.ruc.iir.ws.client.service.impl.GetTourist;
import cn.edu.ruc.iir.ws.client.service.impl.GetTouristResponse;
import cn.edu.ruc.iir.ws.client.service.impl.TourServiceImlp;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceI;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceIStub;
import cn.edu.ruc.iir.ws.client.service.impl.TouristServiceImlp;
import cn.edu.ruc.iir.ws.enterprise.service.impl.FlightServiceImlp;
import cn.edu.ruc.iir.ws.enterprise.service.impl.RoomServiceImlp;
import cn.edu.ruc.iir.ws.service.UserServiceI;
import cn.edu.ruc.iir.ws.service.impl.UserServiceImpl;

public class TestService {

	private static Logger log = Logger.getLogger(TestService.class);

	@Test
	public void getUser() {
		String uname = "taoyouxian";
		UserServiceI userServiceI = new UserServiceImpl();
		String res = userServiceI.getUser(uname);
		log.info("Result: " + res);
	}

	@Test
	public void getTourist() {
		TouristServiceImlp tService = new TouristServiceImlp();
		String res = tService.getTourist();
		log.debug("Result: " + res);
	}

	@Test
	public void getTour() {
		TourServiceImlp tService = new TourServiceImlp();
		String f_day_btime = "2018-01-04";
		String f_start_addr = "北京";
		String f_arrive_addr = "南京";
		int p_days = 3;
		int p_budget = 5200;
		String res = tService.getTour(f_day_btime, f_start_addr, f_arrive_addr, p_days, p_budget);
		log.debug("Result: " + res);
	}

	@Test
	public void getFlight() {
		FlightServiceImlp tService = new FlightServiceImlp();
		String aOrderFields = "f_id desc";
		String aPageSize = "10";
		String aPageIndex = "0";
		String aSqlPs = "";
		String res = tService.getFlight(aOrderFields, aPageSize, aPageIndex, aSqlPs);
		log.debug("Result: " + res);
	}

	@Test
	public void getRoom() {
		RoomServiceImlp tService = new RoomServiceImlp();
		String hid = "2";
		String res = tService.getRoom(hid);
		log.debug("Result: " + res);
	}

	@Test
	public void getTourists() throws RemoteException {
		TouristServiceI tService = new TouristServiceIStub();
		GetTourist g = new GetTourist();
		GetTouristResponse response = tService.getTourist(g);
		String res = response.get_return();
		System.out.println(res);
	}
}
