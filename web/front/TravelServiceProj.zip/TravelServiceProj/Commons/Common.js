﻿/// <reference path="../../../../../applibs/sdk/jQuery-2.1.3.min.js" /> 
/// <reference path="../../../../../applibs/sdk/jQuery.md5.js" />
/// <reference path="../../../../../applibs/sdk/jquery.pin.js" />
/// <reference path="../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="Init.js" />


var Common = {
    Config: {

    },
    Datas: {
        UserInfo: null
    },
    Keys: {
        UserInfoDataKey: "TravelServiceProj.UserInfo",
        Module: ""
    },
    doCheckLogin: function (aCode, aPwd, aCallback) {
        var me = Common;
        try {
            var aInfo = null;
            var aOnCallback = function () {
                hhls.callBack(aCallback, aInfo);
            }
            Ac.acGetTable(Init.Path.Login_checkLogin, { Code: aCode, Pwd: aPwd }, function (aRes) {
                try {
                    if (aRes.Datas.length > 0) {
                        aInfo = aRes.Datas[0];
                    }
                    aOnCallback();
                }
                catch (ee) {
                    aOnCallback();
                }
            });
        }
        catch (e) {; }
    },
    doSaveUserInfo: function (aUserInfo) {
        var me = Common;
        try {
            hhls.saveLocalObj(me.Keys.UserInfoDataKey, aUserInfo);
        }
        catch (e) {; }
    },
    doLoadUserInfo: function (aCallback) {
        var me = Common;
        try {
            var aInfo = hhls.loadLocalObj(me.Keys.UserInfoDataKey);
            if (aInfo == null) {
                hhls.callBack(aCallback, aInfo);
            }
            else {
                try {
                    me.doCheckLogin(aInfo.F_Code, aInfo.F_Pwd, function (aResInfo) {
                        if (aResInfo != null) {
                            me.Datas.UserInfo = aResInfo;
                        }
                        hhls.callBack(aCallback, aResInfo);
                    });
                }
                catch (ee) {
                    hhls.callBack(aCallback, aInfo);
                }
            }

        }
        catch (e) {;}
    },
    doPostChangePwd: function (aPwd0, aPwd1, aPwd2, aCallback) {
        var me = Common;
        try {
            var aRes = { State: 0, Msg: "" };
            if (me.Datas.UserInfo.F_Pwd == aPwd0) {
                if (aPwd1 != aPwd2) {
                    aRes.Msg = "The pwd not the same.";
                    hhls.callBack(aCallback, aRes);
                }
                else {
                    var aPs = { ID: me.Datas.UserInfo.F_ID, Pwd: aPwd1 };
                    Ac.acExecuteSql(Init.Path.Login_changePwd, aPs, function (a) {
                        if (a.State == 1) {
                            aRes.Msg = "Update successfully.";
                            aRes.State = 1;
                            me.Datas.UserInfo.F_Pwd = aPwd1;
                        }
                        else {
                            aRes.Msg = "Update failed.";
                        }
                        hhls.callBack(aCallback, aRes);
                    });
                }
            }
            else {
                aRes.Msg = "Old pwd error.";
                hhls.callBack(aCallback, aRes);
            }
        }
        catch (e) {; }
    },
    /*Common*/
    doInit: function () {
        var me = Common;
        try {
            doInitAcInfo(me.Config.DataSvc.SvcUrl, me.Config.DataSvc.AppKey, me.Config.DataSvc.DBKey, me.Config.DataSvc.WxSrc);
        }
        catch (e) {; }
    },
    doUserAction: function (aAction, aPs, aCallback) {
        var me = Common;
        try {
            var aPath = Init.Path[aAction] != null ? Init.Path[aAction] : "";
            if (aPath.length > 0) {
                Ac.acExecuteSql(aPath, aPs, function (aRes) {
                    hhls.callBack(aCallback, aRes);
                });
            } else {
                hhls.callBack(aCallback, null);
            }
        }
        catch (Ex) {
            var m = Ex;
        }
    },

}