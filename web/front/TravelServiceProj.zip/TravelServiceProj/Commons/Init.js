﻿/// <reference path="../../Libs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../Libs/sdk/json.js" />
/// <reference path="../../Libs/sdk/baiduTpls.js" />
/// <reference path="../../Libs/sdk/date.js" />
/// <reference path="../../Libs/sdk/hhls.js" />
/// <reference path="../../Libs/sdk/hhac.js" />

//初始化系统 
function doInitSys() {
    Ac.Info.SvcUrl = "http://127.0.0.1:8080/dv/getData";
}

var Init = {
    //数据
    Datas: {
        TomcatUrl: "http://127.0.0.1:8080/",
    },
    //sql语句的路径
    Path: {
        // Client
        // Home
        Home_checkLogin: "ws/client/User/checkLogin.txt",
        Home_Login_changePwd: "ws/client/User/Login_changePwd.txt",
        Home_GetAddr: "ws/client/Home/Dict/GetAddr.txt",
        Home_GetBrand: "ws/client/Home/Dict/GetBrand.txt",
        Home_GetPrice: "ws/client/Home/Dict/GetPrice.txt",
        Home_GetStar: "ws/client/Home/Dict/GetStar.txt",
        Home_GetTheme: "ws/client/Home/Dict/GetTheme.txt",

        Home_GetHotel: "ws/client/Home/Hotel/GetHotel.txt",
        Home_GetRoom: "ws/client/Home/Hotel/GetRoom.txt",

        Car_GetType: "ws/client/Car/Dict/GetType.txt",
        Car_GetPreference: "ws/client/Car/Dict/GetPreference.txt",
        Car_GetPrice: "ws/client/Car/Dict/GetPrice.txt",
        Car_GetSeat: "ws/client/Car/Dict/GetSeat.txt",
        Car_GetTransmission: "ws/client/Car/Dict/GetTransmission.txt",

        Car_GetCar: "ws/client/Car/Car/GetCar.txt",

        Flight_GetFlight: "ws/client/Flight/Flight/GetFlight.txt",
        Flight_GetSeat: "ws/client/Flight/Seat/GetSeat.txt",

        //SelfCenter
        Self_GetPlan: "ws/client/SelfCenter/GetPlan.txt",
        Plan_New: "ws/client/SelfCenter/New.txt",
        Plan_Edit: "ws/client/SelfCenter/Edit.txt",

        Plan_Plan: "ws/client/SelfCenter/GetPlans.txt",
        Plan_HotelPlan: "ws/client/SelfCenter/GetHotelPlan.txt",
        Plan_HotelAddPlan: "ws/client/Home/Room/AddHotelPlan.txt",
        Plan_HotelRemovePlan: "ws/client/Home/Room/RemoveHotelPlan.txt",


        Plan_CarPlan: "ws/client/SelfCenter/GetCarPlan.txt",
        Plan_CarAddPlan: "ws/client/Car/AddCarPlan.txt",
        Plan_CarRemovePlan: "ws/client/Car/RemoveCarPlan.txt",


        Plan_FlightPlan: "ws/client/SelfCenter/GetFlightPlan.txt",
        Plan_FlightAddPlan: "ws/client/Flight/AddFlightPlan.txt",
        Plan_FlightRemovePlan: "ws/client/Flight/RemoveFlightPlan.txt",

        Attraction_GetAttraction: "ws/client/Attraction/Attraction/GetAttraction.txt",
        Plan_AttractionPlan: "ws/client/SelfCenter/GetAttractionPlan.txt",
        Plan_AttractionAddPlan: "ws/client/Attraction/AddAttractionPlan.txt",
        Plan_AttractionRemovePlan: "ws/client/Attraction/RemoveAttractionPlan.txt",

        Self_GetTourPlan: "ws/client/SelfCenter/Plan/GetTourPlan.txt",
        Self_PostPlan: "ws/client/SelfCenter/Plan/PostPlan.txt",

        // Manage
        Login_checkLogin: "ws/enterprise/user/checkLogin.txt",
        Login_changePwd: "ws/enterprise/user/changePwd.txt",
        Flight_Flights: "ws/enterprise/Flight/Flights.txt",
        Flight_Edit: "ws/enterprise/Flight/Edit.txt",
        Flight_New: "ws/enterprise/Flight/New.txt",
        Flight_Delete: "ws/enterprise/Flight/Delete.txt",

        Seat_Seats: "ws/enterprise/Seat/Seats.txt",
        Seat_Edit: "ws/enterprise/Seat/Edit.txt",
        Seat_New: "ws/enterprise/Seat/New.txt",
        Seat_Delete: "ws/enterprise/Seat/Delete.txt",

        Room_Rooms: "ws/enterprise/Room/Rooms.txt",
        Room_Edit: "ws/enterprise/Room/Edit.txt",
        Room_New: "ws/enterprise/Room/New.txt",
        Room_Delete: "ws/enterprise/Room/Delete.txt",

        Hotel_Hotels: "ws/enterprise/Hotel/Hotels.txt",
        Hotel_Edit: "ws/enterprise/Hotel/Edit.txt",
        Hotel_New: "ws/enterprise/Hotel/New.txt",
        Hotel_Delete: "ws/enterprise/Hotel/Delete.txt",

        Dict_Addr: "ws/enterprise/Hotel/Dict/Addr.txt",
        Dict_Price: "ws/enterprise/Hotel/Dict/Price.txt",
        Dict_Star: "ws/enterprise/Hotel/Dict/Star.txt",
        Dict_Brand: "ws/enterprise/Hotel/Dict/Brand.txt",
        Dict_Theme: "ws/enterprise/Hotel/Dict/Theme.txt",

        Dicts_Seat: "ws/enterprise/Car/Dict/Seat.txt",
        Dicts_Price: "ws/enterprise/Car/Dict/Price.txt",
        Dicts_Preference: "ws/enterprise/Car/Dict/Preference.txt",
        Dicts_Transmission: "ws/enterprise/Car/Dict/Transmission.txt",
        Dicts_Type: "ws/enterprise/Car/Dict/Type.txt",

        Car_Cars: "ws/enterprise/Car/Cars.txt",
        Car_Edit: "ws/enterprise/Car/Edit.txt",
        Car_New: "ws/enterprise/Car/New.txt",
        Car_Delete: "ws/enterprise/Car/Delete.txt",

        Attraction_Attractions: "ws/enterprise/Attraction/Attractions.txt",
        Attraction_Edit: "ws/enterprise/Attraction/Edit.txt",
        Attraction_New: "ws/enterprise/Attraction/New.txt",
        Attraction_Delete: "ws/enterprise/Attraction/Delete.txt",

        Friend_GetTourist: "ws/client/Friend/GetTourist.txt",
        Recommend_GetTour: "ws/client/Recommend/getTour.txt",


    },
    //web弹出框样式
    Utility: { 
        WebToast: "<div id=\"webToast\">"
                    + "<div class=\"web_transparent\"></div>"
                    + "<div class=\"web-toast\">"
                        + "<div class=\"sk-spinner sk-spinner-three-bounce\">"
                            + "<div class=\"sk-bounce1\"></div>"
                            + "<div class=\"sk-bounce2\"></div>"
                            + "<div class=\"sk-bounce3\"></div>"
                        + "</div>"
                        + "<p class=\"web-toast_content\">数据加载中</p>"
                    + "</div>"
                + "</div>",
    },
    //web弹出框
    WebToast: function (aInfo) {
        var me = Init;
        try {
            $("body").append(me.Utility.WebToast);
            var w = $(window).width();
            var aW = $(".web-toast").width();
            var left = (w - aW) / 2;
            $(".web-toast").css("left", left + "px");
            if(aInfo != "")
            $(".web-toast_content").text(aInfo);
        }
        catch (e) {; }
    },
    //清除弹出框,设置时间
    ClearToast: function (aElement, aTimeOut) {
        var me = Init;
        try { 
            setTimeout(function() {
                $(aElement).remove();
            }, aTimeOut * 1000);
        }
        catch (e) {; }
    },
    //加载图片
    LoadWxImg: function () {
        var me = Init;
        try {
            var aImgs = $(".WxImg");
            $.each(aImgs, function (aInd, aItem) {
                try {
                    var aImg = $(aItem);
                    var aKey = aImg.attr("Key");
                    if (aKey.length > 0) {
                        var aUrl = me.Datas.TomcatUrl + aKey;
                        aImg.attr("src", aUrl);
                    }
                }
                catch (ee) {; }
            });
        }
        catch (e) {; }
    }

}