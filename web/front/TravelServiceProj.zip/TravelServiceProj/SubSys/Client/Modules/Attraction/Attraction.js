﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />
/// <reference path="../Home/Home.js" />


var Attraction = {
    Datas: {
        //旅馆列表信息
        Attractions: {
            OrderFields: "a_id",
            PageSize: 12,
            PageIndex: 1,
            PageCount: [], //页数
            RowCount: [],//总数
            DataList: []
        },
        CurAttractionPlan: {
            a_id: "",
            a_id: "",
        },
        //选择的筛选条件，0、1、2、3   共数组的4条
        Condition: [],
        //选择的那一条租房信息
        AttractionDetail: null,
        //选择参数信息，sql语句的替换参数
        ChooseCaption: {
            a_tour_type: -1, 
            a_location: "",
            a_spot: "",
        }
    },
    Tpls: {
        tplPage: { P: "Modules/Attraction/tplPage.html", C: "" },
        tplList: { P: "Modules/Attraction/tplList.html", C: "" },
        tplPlan: { P: "Modules/Home/tplPlan.html", C: "" },
        tplAttractionDetail: { P: "Modules/Attraction/tplAttractionDetail.html", C: "" },
    },
    Load: function () {
        var me = Attraction;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                    var aHtml = me.Tpls.tplPage.C;
                    hhls.fillElement("#divBody", aHtml);
                    //固定右边详细信息 
                    var aRight = $(".Houses .container .row .col-md-9").offset().left;
                    $(".Houses .container .row .col-md-3").css("right", aRight + "px");

                    var aW = $(".Houses .container .row .col-md-9").width() / 3;
                    $(".Houses .container .row .col-md-3").css("width", aW + "px");

                    Index.RefreshProcess();

                    me.Refresh();
                    if (Common.Datas.UserInfo != null) {
                        Home.getPlans();
                    }
                });
        } catch (e) {; }
    }, 
    Refresh: function () {
        var me = Attraction;
        try {
            //检查搜索框中是否需要有填写
            me.Datas.ChooseCaption.a_tour_type = $("#a_tour_type").val() == "" ? "" : $("#a_tour_type").val();
            me.Datas.ChooseCaption.a_spot = $("#txtQueryText").val() == "" ? "" : $("#txtQueryText").val();
            me.Datas.ChooseCaption.a_location = $("#txtAddrText").val() == "" ? "" : $("#txtAddrText").val();
            //分页查询
            Ac.acGetPageTable(Init.Path.Attraction_GetAttraction, me.Datas.Attractions.OrderFields, me.Datas.Attractions.PageSize, me.Datas.Attractions.PageIndex, me.Datas.ChooseCaption, function (aRes) {
                $("#webToast").remove();
                me.Datas.Attractions = aRes.Datas;
                if (aRes.State == 1) {
                    var aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Attractions });
                    hhls.fillElement(".HouseList", aHtml);
                    //if (me.Datas.Attractions.DataList.length)
                    //    Init.LoadWxImg();
                }
            });
        } catch (e) {; }
    }, 
    //根据Action的数字判断更改页码
    ChangePage: function (aAction) {
        var me = Attraction;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Attractions.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Attractions.PageIndex > 1)
                    me.Datas.Attractions.PageIndex = 1;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Attractions.PageIndex > 1)
                    me.Datas.Attractions.PageIndex--;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Attractions.PageIndex < me.Datas.Attractions.PageCount)
                    me.Datas.Attractions.PageIndex++;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Attractions.PageIndex < me.Datas.Attractions.PageCount)
                    me.Datas.Attractions.PageIndex = me.Datas.Attractions.PageCount;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.Refresh();
        }
        catch (E) {; }
    }, 
    doAddPlan: function (aInfo) {
        var me = Attraction;
        try {
            Init.WebToast();
            //alert(h_id + ", " + aIndex);
            var aID = "dlgAddPlan";
            me.Datas.CurAttractionPlan.a_id = aInfo.a_id;
            //me.Datas.CurAttractionPlan.a_id = a_id;
            a_id = aInfo.a_id;
            
            if (aInfo.u_id == "") {
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            } else {
                var onShow = function (e) {
                    if (Home.Datas.CurPlan.length == 0) {
                        Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                            if (aRes.State == 1) {
                                Home.Datas.CurPlan = aRes.Datas;
                                var aHtml = bt(me.Tpls.tplPlan.C, { tplData: Home.Datas.CurPlan });
                                hhls.fillElement(".divPage", aHtml);
                                me.RefreshPlanState(a_id);
                                $("#webToast").remove();
                            }
                        })
                    } else {
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: Home.Datas.CurPlan });
                        hhls.fillElement(".divPage", aHtml);
                        me.RefreshPlanState(a_id);
                        $("#webToast").remove();
                    }
                };
                var onHide = function (e) {
                    //me.RefreshTable();
                };
                var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
                aDlg.modal("show");
            }
        } catch (e) {; }
    },
    RefreshPlanState: function (a_id) {
        var me = Attraction;
        try {
            var aInfo = { ja_a_id: a_id };
            Ac.acGetTable(Init.Path.Plan_AttractionPlan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    var aPlans = aRes.Datas;

                    var aPlanItems = $(".divPickOrgs .divOrg");
                    var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");
                    $.each(aPlanItems, function (aIndex, aItem) {
                        var aRole = aPlans[aIndex];
                        if (aRole.F_Chk == 1) {
                            $(aPlanItems[aIndex]).attr('onclick', "Attraction.doAttractionPlan(" + a_id + "," + aRole.p_id + ", 0," + aIndex + ");")
                            $(aPlanItems[aIndex]).css("background-color", "#ECF0F5");
                            $(aPlanItem[aIndex]).css("display", "");
                            //$(aPlanItem[aIndex]).css("color", "green");
                        } else {
                            $(aPlanItems[aIndex]).attr('onclick', "Attraction.doAttractionPlan(" + a_id + "," + aRole.p_id + ", 1," + aIndex + ");")
                        }
                    });

                }
            });
        } catch (e) {; }
    },
    doAttractionPlan: function (a_id, p_id, aboder, aIndex) {
        var me = Attraction;
        try {
            var aAction = aboder ? "Plan_AttractionAddPlan" : "Plan_AttractionRemovePlan";
            var aPlanItems = $(".divPickOrgs .divOrg");
            var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");

            $(aPlanItems[aIndex]).css("background-color", aboder ? "#ECF0F5" : "#fff");
            $(aPlanItem[aIndex]).css("display", aboder ? "" : "none");

            if (aboder == 0) {
                $(aPlanItems[aIndex]).attr('onclick', "Attraction.doAttractionPlan(" + a_id + "," + p_id + ", 1," + aIndex + ");")
            } else {
                $(aPlanItems[aIndex]).attr('onclick', "Attraction.doAttractionPlan(" + a_id + "," + p_id + ", 0," + aIndex + ");")
            }
            var aInfo = {
                ja_p_id: p_id,
                ja_a_id: a_id
            };
            Common.doUserAction(aAction, aInfo, function () {

            })
        } catch (e) {; }
    },
    //查看详情
    ShowDetail: function (aIndex) {
        var me = Attraction;
        try {
            Init.WebToast();
            var aInfo = me.Datas.Attractions.DataList[aIndex];
            if (aInfo != null) {
                var aHtml = bt(me.Tpls.tplAttractionDetail.C, { tplData: aInfo });
                hhls.fillElement(".HouseDetail", aHtml);
                var aData = {
                    u_id: $("#UID").val(),
                    a_id: aInfo.a_id
                }; 
            }
            $(".divTour").css("background-color", "");
            $($(".divTour")[aIndex]).css("background-color", "#fff");
            $("#webToast").remove();
            me.Datas.AttractionDetail = aInfo;
        } catch (e) {; }
    },
    //加入我的收藏
    doCollect: function () {
        var me = Attraction;
        try {
            //Init.WebToast();
            var aInfo = {
                u_id: $("#UID").val(),
                a_id: me.Datas.AttractionDetail.a_id
            };
            me.doAddPlan(aInfo); 
        } catch (e) {; }
    },
    //搜索框中信息
    doSearchRefresh: function () {
        var me = Attraction;
        try {
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    }
};