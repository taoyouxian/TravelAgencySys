﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />
/// <reference path="../Home/Home.js" />


var Car = {
    Datas: {
        //旅馆列表信息
        Cars: {
            OrderFields: "ctime desc",
            PageSize: 5,
            PageIndex: 1,
            PageCount: [], //页数
            RowCount: [],//总数
            DataList: []
        },
        CurCarPlan: {
            c_id: "",
            r_id: "",
        },
        Type: [
           { Caption: "不限" },
        ],
        Preference: [
           { Caption: "不限" },
        ],
        Price: [
            { Caption: "不限" },
        ],
        Seat: [
            { Caption: "不限" },
        ],
        Transmission: [
            { Caption: "不限" },
        ],
        //选择的筛选条件，0、1、2、3   共数组的4条
        Condition: [],
        //选择的那一条租房信息
        CarDetail: null,
        //选择参数信息，sql语句的替换参数
        ChooseCaption: {
            TyID: 0,
            PreID: 0,
            PriID: 0,
            SID: 0,
            TrID: 0,
            c_address: "",
            c_name: "",
        }
    },
    Tpls: {
        tplPage: { P: "Modules/Car/tplPage.html", C: "" },
        tplList: { P: "Modules/Car/tplList.html", C: "" },
        tplPlan: { P: "Modules/Home/tplPlan.html", C: "" },
        tplCarDetail: { P: "Modules/Car/tplCarDetail.html", C: "" },
    },
    Load: function () {
        var me = Car;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                me.getDicts(function () {
                    var aHtml = me.Tpls.tplPage.C;
                    hhls.fillElement("#divBody", aHtml);
                    //固定右边详细信息 
                    var aRight = $(".Houses .container .row .col-md-9").offset().left;
                    $(".Houses .container .row .col-md-3").css("right", aRight + "px");

                    var aW = $(".Houses .container .row .col-md-9").width() / 3;
                    $(".Houses .container .row .col-md-3").css("width", aW + "px");
                    me.InitCondition();

                    Index.RefreshProcess();

                    me.Refresh();

                    if (Common.Datas.UserInfo != null) {
                        Home.getPlans();
                    }
                });
            });
        } catch (e) {; }
    },
    //获得字典参数，多个数据Table集
    getDicts: function (aCallBack) {
        var me = Car;
        try {
            var aTables = {
                Type: Init.Path.Car_GetType,
                Preference: Init.Path.Car_GetPreference,
                Price: Init.Path.Car_GetPrice,
                Seat: Init.Path.Car_GetSeat,
                Transmission: Init.Path.Car_GetTransmission,
            };
            Ac.acGetDs(aTables, {}, function (aRes) {
                //将不限与后台获取的数据合并
                me.Datas.Type = aRes.Datas.Type;
                me.Datas.Preference = aRes.Datas.Preference;
                me.Datas.Price = aRes.Datas.Price;
                me.Datas.Seat = aRes.Datas.Seat;
                me.Datas.Transmission = aRes.Datas.Transmission;
                hhls.callBack(aCallBack);
            });
        } catch (e) {; }
    },
    Refresh: function () {
        var me = Car;
        try {
            //检查搜索框中是否需要有填写
            me.Datas.ChooseCaption.c_name = $("#txtQueryText").val() == "" ? "" : $("#txtQueryText").val();
            me.Datas.ChooseCaption.c_address = $("#txtAddrText").val() == "" ? "" : $("#txtAddrText").val();
            //分页查询
            Ac.acGetPageTable(Init.Path.Car_GetCar, me.Datas.Cars.OrderFields, me.Datas.Cars.PageSize, me.Datas.Cars.PageIndex, me.Datas.ChooseCaption, function (aRes) {
                $("#webToast").remove();
                me.Datas.Cars = aRes.Datas;
                if (aRes.State == 1) {
                    var aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Cars });
                    hhls.fillElement(".HouseList", aHtml);
                    if (me.Datas.Cars.DataList.length)
                        Init.LoadWxImg();
                }
            });
        } catch (e) {; }
    },
    //初始化显示条件信息，一维数组
    InitCondition: function () {
        var me = Car;
        try {
            me.AppendData(".divType table tr", 0, me.Datas.Type);
            me.AppendData(".divPreference table tr", 1, me.Datas.Preference);
            me.AppendData(".divPrice table tr", 2, me.Datas.Price);
            me.AppendData(".divSeat table tr", 3, me.Datas.Seat);
            me.AppendData(".divTransmission table tr", 4, me.Datas.Transmission);
        } catch (e) {; }
    },
    AppendData: function (aElement, aKind, aInfo) {
        var aStr = "";
        var aOnclick = "";
        for (var i in aInfo) {
            aOnclick = "onclick='Car.PickItem(" + i + ", " + aKind + ")'";
            aStr += "<td class='editor' " + aOnclick + ">" + aInfo[i].Caption + "</td>";
        }
        $(aElement).append(aStr);
        var aMenu = $(aElement + " .editor");
        aMenu.removeClass("active");
        $(aMenu[0]).addClass("active");
    },
    //选择筛选条件
    PickItem: function (aIndex, aKind) {
        var me = Car;
        try {
            var aMenu = "";
            var aInfo = {};
            if (aKind == 0) {
                aMenu = $(".divType table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Type[aIndex].Caption;
                aInfo.P = "Type";
                me.Datas.ChooseCaption.TyID = aIndex;
            } else if (aKind == 1) {
                aMenu = $(".divPreference table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Preference[aIndex].Caption;
                aInfo.P = "Preference";
                me.Datas.ChooseCaption.PreID = aIndex;
            } else if (aKind == 2) {
                aMenu = $(".divPrice table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Price[aIndex].Caption;
                aInfo.P = "Price";
                me.Datas.ChooseCaption.PriID = aIndex;
            } else if (aKind == 3) {
                aMenu = $(".divSeat table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Seat[aIndex].Caption;
                aInfo.P = "Seat";
                me.Datas.ChooseCaption.SID = aIndex;
            } else if (aKind == 4) {
                aMenu = $(".divTransmission table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Transmission[aIndex].Caption;
                aInfo.P = "Transmission";
                me.Datas.ChooseCaption.TrID = aIndex;
            }
            aMenu.removeClass("active");
            $(aMenu[aIndex]).addClass("active");

            me.Datas.Condition[aKind] = aInfo;
            me.ReplaceData();
        } catch (e) {; }
    },
    //在筛选条件后面显示
    ReplaceData: function () {
        var me = Car;
        try {
            var aStr = "";
            var aOnclick = "";
            for (var i in me.Datas.Condition) {
                if (me.Datas.Condition[i].C != "") {
                    aOnclick = "Car.ClearItem(" + i + ",'" + me.Datas.Condition[i].P + "')";
                    aStr += "<td class='searchBtn " + i + "'><button class='btn btn-xs btn-warning' onclick=" + aOnclick + ">" + me.Datas.Condition[i].C + " <i class='fa fa-close text-danger'></i></button></td>";
                }
            }
            $(".searchBtn").remove();
            if (aStr != "") {
                $("#lab").css("display", "none");
                $(".divSearch table tr").append(aStr);
            } else {
                $("#lab").css("display", "");
            }
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    },
    //筛选条件中的清除
    ClearItem: function (aIndex, aStr) {
        var me = Car;
        try {
            Init.WebToast();
            $(".divSearch table tr td." + aIndex).remove();
            var aElement = ".div" + aStr + " table tr .editor"
            var aMenu = $(aElement);
            aMenu.removeClass("active");
            $(aMenu[0]).addClass("active");

            if (aStr == "Type") {
                me.Datas.ChooseCaption.TyID = 0;
                me.Datas.Condition[0].C = "";
            }
            else if (aStr == "Preference") {
                me.Datas.ChooseCaption.PreID = 0;
                me.Datas.Condition[1].C = "";
            }
            else if (aStr == "Price") {
                me.Datas.ChooseCaption.PriID = 0;
                me.Datas.Condition[2].C = "";
            }
            else if (aStr == "Seat") {
                me.Datas.ChooseCaption.SID = 0;
                me.Datas.Condition[3].C = "";
            }
            else if (aStr == "Transmission") {
                me.Datas.ChooseCaption.TrID = 0;
                me.Datas.Condition[4].C = "";
            }
            if (me.Datas.ChooseCaption.TyID == 0 && me.Datas.ChooseCaption.PreID == 0 && me.Datas.ChooseCaption.PriID == 0 && me.Datas.ChooseCaption.SID == 0 && me.Datas.ChooseCaption.TrID == 0) {
                $("#lab").css("display", "");
            }
            me.Refresh();

        } catch (e) {; }
    },
    //根据Action的数字判断更改页码
    ChangePage: function (aAction) {
        var me = Car;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Cars.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Cars.PageIndex > 1)
                    me.Datas.Cars.PageIndex = 1;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Cars.PageIndex > 1)
                    me.Datas.Cars.PageIndex--;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Cars.PageIndex < me.Datas.Cars.PageCount)
                    me.Datas.Cars.PageIndex++;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Cars.PageIndex < me.Datas.Cars.PageCount)
                    me.Datas.Cars.PageIndex = me.Datas.Cars.PageCount;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.Refresh();
        }
        catch (E) {; }
    }, 
    doAddPlan: function (aInfo) {
        var me = Car;
        try {
            Init.WebToast();
            //alert(h_id + ", " + aIndex);
            var aID = "dlgAddPlan";
            me.Datas.CurCarPlan.c_id = aInfo.c_id;
            //me.Datas.CurCarPlan.r_id = r_id;
            c_id = aInfo.c_id;
            
            if (aInfo.u_id == "") {
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            } else {
                var onShow = function (e) {
                    if (Home.Datas.CurPlan.length == 0) {
                        Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                            if (aRes.State == 1) {
                                Home.Datas.CurPlan = aRes.Datas;
                                var aHtml = bt(me.Tpls.tplPlan.C, { tplData: Home.Datas.CurPlan });
                                hhls.fillElement(".divPage", aHtml);
                                me.RefreshPlanState(c_id);
                                $("#webToast").remove();
                            }
                        })
                    } else {
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: Home.Datas.CurPlan });
                        hhls.fillElement(".divPage", aHtml);
                        me.RefreshPlanState(c_id);
                        $("#webToast").remove();
                    }
                };
                var onHide = function (e) {
                    //me.RefreshTable();
                };
                var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
                aDlg.modal("show");
            }
        } catch (e) {; }
    },
    RefreshPlanState: function (c_id) {
        var me = Car;
        try {
            var aInfo = { jc_c_id: c_id };
            Ac.acGetTable(Init.Path.Plan_CarPlan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    var aPlans = aRes.Datas;

                    var aPlanItems = $(".divPickOrgs .divOrg");
                    var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");
                    $.each(aPlanItems, function (aIndex, aItem) {
                        var aRole = aPlans[aIndex];
                        if (aRole.F_Chk == 1) {
                            $(aPlanItems[aIndex]).attr('onclick', "Car.doCarPlan(" + c_id + "," + aRole.p_id + ", 0," + aIndex + ");")
                            $(aPlanItems[aIndex]).css("background-color", "#ECF0F5");
                            $(aPlanItem[aIndex]).css("display", "");
                            //$(aPlanItem[aIndex]).css("color", "green");
                        } else {
                            $(aPlanItems[aIndex]).attr('onclick', "Car.doCarPlan(" + c_id + "," + aRole.p_id + ", 1," + aIndex + ");")
                        }
                    });

                }
            });
        } catch (e) {; }
    },
    doCarPlan: function (r_id, p_id, aboder, aIndex) {
        var me = Car;
        try {
            var aAction = aboder ? "Plan_CarAddPlan" : "Plan_CarRemovePlan";
            var aPlanItems = $(".divPickOrgs .divOrg");
            var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");

            $(aPlanItems[aIndex]).css("background-color", aboder ? "#ECF0F5" : "#fff");
            $(aPlanItem[aIndex]).css("display", aboder ? "" : "none");

            if (aboder == 0) {
                $(aPlanItems[aIndex]).attr('onclick', "Car.doCarPlan(" + r_id + "," + p_id + ", 1," + aIndex + ");")
            } else {
                $(aPlanItems[aIndex]).attr('onclick', "Car.doCarPlan(" + r_id + "," + p_id + ", 0," + aIndex + ");")
            }
            var aInfo = {
                jc_p_id: p_id,
                jc_c_id: r_id
            };
            Common.doUserAction(aAction, aInfo, function () {

            })
        } catch (e) {; }
    },
    //查看详情
    ShowDetail: function (aIndex) {
        var me = Car;
        try {
            Init.WebToast();
            var aInfo = me.Datas.Cars.DataList[aIndex];
            if (aInfo != null) {
                var aHtml = bt(me.Tpls.tplCarDetail.C, { tplData: aInfo });
                hhls.fillElement(".HouseDetail", aHtml);
                var aData = {
                    u_id: $("#UID").val(),
                    c_id: aInfo.c_id
                };
                //判断是否已经收藏
                //Ac.acGetTable(Init.Path.Home_GetCollectState, aData, function (aRes) {
                //    if (aRes.Datas[0].F_Count == 0) {
                //        $("#webToast").remove();
                //    }
                //        //已经收藏过，更改样式，除去onclick事件
                //    else {
                //        $(".web-toast_content").text("这条旅馆信息已经在收藏中");
                //        $("#collectBtn").attr("onclick", "");
                //        $("#collectBtn").removeClass("btn-danger").addClass("btn-primary");
                //        hhls.fillElement("#collectBtn", '<i class="fa fa-heart"></i> 已收藏');
                //        Init.ClearToast("#webToast", 1)
                //    }
                //}) 
            }
            $("#webToast").remove();
            me.Datas.CarDetail = aInfo;
        } catch (e) {; }
    },
    //加入我的收藏
    doCollect: function () {
        var me = Car;
        try {
            //Init.WebToast();
            var aInfo = {
                u_id: $("#UID").val(),
                c_id: me.Datas.CarDetail.c_id
            };
            me.doAddPlan(aInfo);
            //if (aInfo.UID == "") {
            //    $(".web-toast_content").text("请您先登录!");
            //    Init.ClearToast("#webToast", 1)
            //} else {
            //    Ac.acExecuteSql(Init.Path.Car_doCollect, aInfo, function (aRes) {
            //        $(".web-toast_content").text(aRes.State == 1 ? "收藏成功！" : "收藏失败！");
            //        if (aRes.State == 1) {
            //            $("#collectBtn").attr("onclick", "");
            //            $("#collectBtn").removeClass("btn-danger").addClass("btn-primary");
            //            hhls.fillElement("#collectBtn", '<i class="fa fa-heart"></i> 已收藏');
            //        } else {
            //        }
            //        Init.ClearToast("#webToast", 1)
            //    }) 
            //}
        } catch (e) {; }
    },
    //搜索框中信息
    doSearchRefresh: function () {
        var me = Car;
        try {
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    }
};