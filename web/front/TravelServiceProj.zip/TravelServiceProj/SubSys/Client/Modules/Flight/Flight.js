﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />


var Flight = {
    Datas: {
        //旅馆列表信息
        Houses: {
            OrderFields: "f_price ", // 建立时间 desc
            PageSize: 5,
            PageIndex: 1,
            PageCount: [], //页数
            RowCount: [],//总数
            DataList: [],
        },
        CurFlightPlan: {
            s_f_id: "",
            s_id: "",
        },
        Seats: [],
        CurPlan: [],
        Addr: [
           { Caption: "不限" },
        ],
        Brand: [
           { Caption: "不限" },
        ],
        Price: [
            { Caption: "不限" },
        ],
        Star: [
            { Caption: "不限" },
        ],
        Theme: [
            { Caption: "不限" },
        ],
        //选择的筛选条件，0、1、2、3   共数组的4条
        Condition: [],
        //选择的那一条租房信息
        FlightDetail: null,
        //选择参数信息，sql语句的替换参数
        ChooseCaption: {
            f_start_addr: "",
            f_arrive_addr: "",
            f_start_time: "",
            f_arrive_time: "",
            f_caption: "",
        }
    },
    Tpls: {
        tplPage: { P: "Modules/Flight/tplPage.html", C: "" },
        tplList: { P: "Modules/Flight/tplList.html", C: "" },
        tplFlightDetail: { P: "Modules/Flight/tplFlightDetail.html", C: "" },
        tplSeat: { P: "Modules/Flight/tplSeat.html", C: "" },
        tplPlan: { P: "Modules/Flight/tplPlan.html", C: "" },
    },
    Load: function () {
        var me = Flight;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                    var aHtml = me.Tpls.tplPage.C;
                    hhls.fillElement("#divBody", aHtml);

                $('.dtp').datetimepicker({
                        language: 'zh-CN',
                        minView: "month", //选择日期后，不会再跳转去选择时分秒 
                        format: "yyyy-mm-dd",
                        weekStart: 1,
                        todayBtn: 1,
                        autoclose: 1,
                        todayHighlight: 1,
                        startView: 2,
                        forceParse: 0,
                        showMeridian: 1
                    }).on('changeDate', function (ev) {
                        $(this).datetimepicker('hide');
                    });

                    $('#dtpFrom').val((new Date()).toString("yyyy-MM-dd")).datetimepicker("update");
                    $('#dtpTo').val((new Date().addDays(7)).toString("yyyy-MM-dd")).datetimepicker("update");

                    //固定右边详细信息 
                    var aRight = $(".Houses .container .row .col-md-9").offset().left;
                    $(".Houses .container .row .col-md-3").css("right", aRight + "px");

                    var aW = $(".Houses .container .row .col-md-9").width() / 3;
                    $(".Houses .container .row .col-md-3").css("width", aW + "px");

                    Index.RefreshProcess();

                    me.Refresh();
                    if (Common.Datas.UserInfo != null) {
                        me.getPlans();
                    }
                });
        } catch (e) {; }
    },
    getPlans: function () {
        var me = Flight;
        try {
            me.Datas.CurPlan = [];
            var aInfo = {
                u_id: $("#UID").val(),
            };
            Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    me.Datas.CurPlan = aRes.Datas;
                    var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                    hhls.fillElement(".divPage", aHtml);
                }
                $("#webToast").remove();
            })
        } catch (e) {; }
    }, 
    Refresh: function () {
        var me = Flight;
        try {
            //检查搜索框中是否需要有填写
            me.Datas.ChooseCaption.f_start_addr = $("#txtStart_Addr").val() == "" ? "" : $("#txtStart_Addr").val();
            me.Datas.ChooseCaption.f_arrive_addr = $("#txtArrive_Addr").val() == "" ? "" : $("#txtArrive_Addr").val();
            me.Datas.ChooseCaption.f_start_time = $("#dtpFrom").val() == "" ? "" : $("#dtpFrom").val();
            me.Datas.ChooseCaption.f_arrive_time = $("#dtpTo").val() == "" ? "" : $("#dtpTo").val();
            //分页查询
            Ac.acGetPageTable(Init.Path.Flight_GetFlight, me.Datas.Houses.OrderFields, me.Datas.Houses.PageSize, me.Datas.Houses.PageIndex, me.Datas.ChooseCaption, function (aRes) {
                $("#webToast").remove();
                me.Datas.Houses = aRes.Datas;
                if (aRes.State == 1) {
                    var aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Houses });
                    hhls.fillElement(".HouseList", aHtml);
                    //if (me.Datas.Houses.DataList.length)
                    //    Init.LoadWxImg();
                }
            });
        } catch (e) {; }
    }, 
    //根据Action的数字判断更改页码
    ChangePage: function (aAction) {
        var me = Flight;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Houses.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Houses.PageIndex > 1)
                    me.Datas.Houses.PageIndex = 1;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Houses.PageIndex > 1)
                    me.Datas.Houses.PageIndex--;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Houses.PageIndex < me.Datas.Houses.PageCount)
                    me.Datas.Houses.PageIndex++;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Houses.PageIndex < me.Datas.Houses.PageCount)
                    me.Datas.Houses.PageIndex = me.Datas.Houses.PageCount;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.Refresh();
        }
        catch (E) {; }
    },
    doShowSeat: function (seat, aIndex) {
        var me = Flight;
        try {
            if (seat == 0) {
                Init.WebToast();

                var aFlight = me.Datas.Houses.DataList[aIndex];
                var aInfo = {
                    s_f_id: aFlight.f_id
                };
                Ac.acGetTable(Init.Path.Flight_GetSeat, aInfo, function (aRes) {
                    if (aRes.State == 1) {
                        me.Datas.Seats = aRes.Datas;
                        var aHtml = bt(me.Tpls.tplSeat.C, { tplData: me.Datas.Seats });
                        hhls.fillElement(".table" + aIndex, aHtml);
                    }
                })
                $(".seat" + aIndex).attr('onclick', "Flight.doShowSeat(1, " + aIndex + ");")
                $(".label" + aIndex).css('display', "none");
                hhls.fillElement(".seat" + aIndex, '<i class="fa fa-sort-asc"></i> 收起'); 
                $("#webToast").remove();
            } else {
                $(".seat" + aIndex).attr('onclick', "Flight.doShowSeat(0, " + aIndex + ");")
                $(".label" + aIndex).css('display', "");
                hhls.fillElement(".seat" + aIndex, '<i class="fa fa-sort-down"></i> 订票');
                hhls.fillElement(".table" + aIndex, "");
            }
        } catch (e) {; }
    },
    doAddPlan: function (s_f_id, aIndex, s_id) {
        var me = Flight;
        try {
            Init.WebToast();
            var aID = "dlgAddPlan";
            me.Datas.CurFlightPlan.s_f_id = s_f_id;
            me.Datas.CurFlightPlan.s_id = s_id;
            var aInfo = {
                u_id: $("#UID").val(),
                jf_f_id: s_f_id
            };
            if (aInfo.u_id == "") {
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            } else {
                var onShow = function (e) {
                    if (me.Datas.CurPlan.length == 0) {
                        Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                            if (aRes.State == 1) {
                                me.Datas.CurPlan = aRes.Datas;
                                var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                                hhls.fillElement(".divPage", aHtml);
                                me.RefreshPlanState(s_id);
                                $("#webToast").remove();
                            }
                        })
                    } else {
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                        hhls.fillElement(".divPage", aHtml);
                        me.RefreshPlanState(s_id);
                        $("#webToast").remove();
                    }
                };
                var onHide = function (e) {
                    //me.RefreshTable();
                };
                var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
                aDlg.modal("show");
            }
        } catch (e) {; }
    },
    RefreshPlanState: function (s_id) {
        var me = Flight;
        try {
            var aInfo = { jf_s_id: s_id };
            Ac.acGetTable(Init.Path.Plan_FlightPlan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    var aPlans = aRes.Datas;

                    var aPlanItems = $(".divPickOrgs .divOrg");
                    var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");
                    $.each(aPlanItems, function (aIndex, aItem) {
                        var aRole = aPlans[aIndex];
                        if (aRole.F_Chk == 1) {
                            $(aPlanItems[aIndex]).attr('onclick', "Flight.doFlightPlan(" + s_id + "," + aRole.p_id + ", 0,"+ aIndex + ");")
                            $(aPlanItems[aIndex]).css("background-color", "#ECF0F5");
                            $(aPlanItem[aIndex]).css("display", "");
                        } else {
                            $(aPlanItems[aIndex]).attr('onclick', "Flight.doFlightPlan(" + s_id + "," + aRole.p_id + ", 1,"+ aIndex + ");")
                        }
                    });

                }
            });
        } catch (e) {; }
    },
    doFlightPlan: function (s_id, p_id, aboder, aIndex) {
        var me = Flight;
        try {
            var aAction = aboder ? "Plan_FlightAddPlan" : "Plan_FlightRemovePlan";
            var aPlanItems = $(".divPickOrgs .divOrg");
            var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");

            $(aPlanItems[aIndex]).css("background-color", aboder ? "#ECF0F5" : "#fff");
            $(aPlanItem[aIndex]).css("display", aboder ? "" : "none");
            if (aboder == 0) {
                $(aPlanItems[aIndex]).attr('onclick', "Flight.doFlightPlan(" + s_id + "," + p_id + ", 1,"+ aIndex + ");")
            } else {
                $(aPlanItems[aIndex]).attr('onclick', "Flight.doFlightPlan(" + s_id + "," + p_id + ", 0,"+ aIndex + ");")
            }
            var aInfo = {
                jf_p_id: p_id,
                jf_s_id: s_id
            };
            Common.doUserAction(aAction, aInfo, function () {

            })
        } catch (e) {; }
    }, 
    //搜索框中信息
    doSearchRefresh: function () {
        var me = Flight;
        try {
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    }
};