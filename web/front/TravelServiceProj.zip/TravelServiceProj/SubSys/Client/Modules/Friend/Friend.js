﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />


var Friend = {
    Datas: {
        Tourist:[],
    },
    Tpls: {
        tplPlan: { P: "Modules/Friend/tplPlan.html", C: "" },
        tplPage: { P: "Modules/Friend/tplPage.html", C: "" },
    },
    Load: function () {
        var me = Friend;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                var aHtml = me.Tpls.tplPage.C;
                hhls.fillElement("#divBody", aHtml);

                Index.RefreshProcess();
                me.Refresh();
            });
        } catch (e) {; }
    },
    Refresh: function () {
        var me = Friend;
        try {
            Ac.acGetTable(Init.Path.Friend_GetTourist, {}, function (aRes) {
                if (aRes.State == 1) {
                    me.Datas.Tourist = aRes.Datas;
                    var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.Tourist });
                    hhls.fillElement(".HouseList", aHtml);
                }
                $("#webToast").remove();
            })
        } catch (e) {; }
    },
};