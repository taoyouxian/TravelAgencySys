﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />


var Home = {
    Datas: {
        //旅馆列表信息
        Houses: {
            OrderFields: "htime ", // 建立时间 desc
            PageSize: 5,
            PageIndex: 1,
            PageCount: [], //页数
            RowCount: [],//总数
            DataList: [],
        },
        CurHotelPlan: {
            h_id: "",
            r_id: "",
        },
        Rooms: [],
        CurPlan: [],
        Addr: [
           { Caption: "不限" },
        ],
        Brand: [
           { Caption: "不限" },
        ],
        Price: [
            { Caption: "不限" },
        ],
        Star: [
            { Caption: "不限" },
        ],
        Theme: [
            { Caption: "不限" },
        ],
        //选择的筛选条件，0、1、2、3   共数组的4条
        Condition: [],
        //选择的那一条租房信息
        HouseDetail: null,
        //选择参数信息，sql语句的替换参数
        ChooseCaption: {
            AID: 0,
            PID: 0,
            SID: 0,
            BID: 0,
            TID: 0,
            h_address: "",
            h_name: "",
        }
    },
    Tpls: {
        tplPage: { P: "Modules/Home/tplPage.html", C: "" },
        tplList: { P: "Modules/Home/tplList.html", C: "" },
        tplHouseDetail: { P: "Modules/Home/tplHouseDetail.html", C: "" },
        tplRoom: { P: "Modules/Home/tplRoom.html", C: "" },
        tplPlan: { P: "Modules/Home/tplPlan.html", C: "" },
    },
    Load: function () {
        var me = Home;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                me.getDicts(function () {
                    var aHtml = me.Tpls.tplPage.C;
                    hhls.fillElement("#divBody", aHtml);
                    //固定右边详细信息 
                    var aRight = $(".Houses .container .row .col-md-9").offset().left;
                    $(".Houses .container .row .col-md-3").css("right", aRight + "px");

                    var aW = $(".Houses .container .row .col-md-9").width() / 3;
                    $(".Houses .container .row .col-md-3").css("width", aW + "px");
                    me.InitCondition();

                    Index.RefreshProcess();

                    me.Refresh();
                    if (Common.Datas.UserInfo != null) {
                        me.getPlans();
                    }
                });
            });
        } catch (e) {; }
    },
    getPlans: function () {
        var me = Home;
        try {
            me.Datas.CurPlan = [];
            var aInfo = {
                u_id: $("#UID").val(),
            };
            Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    me.Datas.CurPlan = aRes.Datas;
                    var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                    hhls.fillElement(".divPage", aHtml);
                }
                $("#webToast").remove();
            })
        } catch (e) {; }
    },
    //获得字典参数，多个数据Table集
    getDicts: function (aCallBack) {
        var me = Home;
        try {
            var aTables = {
                Addr: Init.Path.Home_GetAddr,
                Brand: Init.Path.Home_GetBrand,
                Price: Init.Path.Home_GetPrice,
                Star: Init.Path.Home_GetStar,
                Theme: Init.Path.Home_GetTheme,
            };
            Ac.acGetDs(aTables, {}, function (aRes) {
                //将不限与后台获取的数据合并
                me.Datas.Addr = aRes.Datas.Addr;
                me.Datas.Brand = aRes.Datas.Brand;
                me.Datas.Price = aRes.Datas.Price;
                me.Datas.Star = aRes.Datas.Star;
                me.Datas.Theme = aRes.Datas.Theme;
                hhls.callBack(aCallBack);
            });
        } catch (e) {; }
    },
    Refresh: function () {
        var me = Home;
        try {
            //检查搜索框中是否需要有填写
            me.Datas.ChooseCaption.h_name = $("#txtQueryText").val() == "" ? "" : $("#txtQueryText").val();
            me.Datas.ChooseCaption.h_address = $("#txtAddrText").val() == "" ? "" : $("#txtAddrText").val();
            //分页查询
            Ac.acGetPageTable(Init.Path.Home_GetHotel, me.Datas.Houses.OrderFields, me.Datas.Houses.PageSize, me.Datas.Houses.PageIndex, me.Datas.ChooseCaption, function (aRes) {
                $("#webToast").remove();
                me.Datas.Houses = aRes.Datas;
                if (aRes.State == 1) {
                    var aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Houses });
                    hhls.fillElement(".HouseList", aHtml);
                    if (me.Datas.Houses.DataList.length)
                        Init.LoadWxImg();
                }
            });
        } catch (e) {; }
    },
    //初始化显示条件信息，一维数组
    InitCondition: function () {
        var me = Home;
        try {
            me.AppendData(".divAddr table tr", 0, me.Datas.Addr);
            me.AppendData(".divPrice table tr", 1, me.Datas.Price);
            me.AppendData(".divStar table tr", 2, me.Datas.Star);
            me.AppendData(".divBrand table tr", 3, me.Datas.Brand);
            me.AppendData(".divTheme table tr", 4, me.Datas.Theme);
        } catch (e) {; }
    },
    AppendData: function (aElement, aKind, aInfo) {
        var aStr = "";
        var aOnclick = "";
        for (var i in aInfo) {
            aOnclick = "onclick='Home.PickItem(" + i + ", " + aKind + ")'";
            aStr += "<td class='editor' " + aOnclick + ">" + aInfo[i].Caption + "</td>";
        }
        $(aElement).append(aStr);
        var aMenu = $(aElement + " .editor");
        aMenu.removeClass("active");
        $(aMenu[0]).addClass("active");
    },
    //选择筛选条件
    PickItem: function (aIndex, aKind) {
        var me = Home;
        try {
            var aMenu = "";
            var aInfo = {};
            if (aKind == 0) {
                aMenu = $(".divAddr table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Addr[aIndex].Caption;
                aInfo.P = "Addr";
                me.Datas.ChooseCaption.AID = aIndex;
            } else if (aKind == 1) {
                aMenu = $(".divPrice table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Price[aIndex].Caption;
                aInfo.P = "Price";
                me.Datas.ChooseCaption.PID = aIndex;
            } else if (aKind == 2) {
                aMenu = $(".divStar table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Star[aIndex].Caption;
                aInfo.P = "Star";
                me.Datas.ChooseCaption.SID = aIndex;
            } else if (aKind == 3) {
                aMenu = $(".divBrand table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Brand[aIndex].Caption;
                aInfo.P = "Brand";
                me.Datas.ChooseCaption.BID = aIndex;
            } else if (aKind == 4) {
                aMenu = $(".divTheme table tr .editor");
                aInfo.C = aIndex == 0 ? "" : me.Datas.Theme[aIndex].Caption;
                aInfo.P = "Theme";
                me.Datas.ChooseCaption.TID = aIndex;
            }
            aMenu.removeClass("active");
            $(aMenu[aIndex]).addClass("active");

            me.Datas.Condition[aKind] = aInfo;
            me.ReplaceData();
        } catch (e) {; }
    },
    //在筛选条件后面显示
    ReplaceData: function () {
        var me = Home;
        try {
            var aStr = "";
            var aOnclick = "";
            for (var i in me.Datas.Condition) {
                if (me.Datas.Condition[i].C != "") {
                    aOnclick = "Home.ClearItem(" + i + ",'" + me.Datas.Condition[i].P + "')";
                    aStr += "<td class='searchBtn " + i + "'><button class='btn btn-xs btn-warning' onclick=" + aOnclick + ">" + me.Datas.Condition[i].C + " <i class='fa fa-close text-danger'></i></button></td>";
                }
            }
            $(".searchBtn").remove();
            if (aStr != "") {
                $("#lab").css("display", "none");
                $(".divSearch table tr").append(aStr);
            } else {
                $("#lab").css("display", "");
            }
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    },
    //筛选条件中的清除
    ClearItem: function (aIndex, aStr) {
        var me = Home;
        try {
            Init.WebToast();
            $(".divSearch table tr td." + aIndex).remove();
            var aElement = ".div" + aStr + " table tr .editor"
            var aMenu = $(aElement);
            aMenu.removeClass("active");
            $(aMenu[0]).addClass("active");

            if (aStr == "Addr") {
                me.Datas.ChooseCaption.AID = 0;
                me.Datas.Condition[0].C = "";
            }
            else if (aStr == "Price") {
                me.Datas.ChooseCaption.PID = 0;
                me.Datas.Condition[1].C = "";
            }
            else if (aStr == "Star") {
                me.Datas.ChooseCaption.SID = 0;
                me.Datas.Condition[2].C = "";
            }
            else if (aStr == "Brand") {
                me.Datas.ChooseCaption.BID = 0;
                me.Datas.Condition[3].C = "";
            }
            else if (aStr == "Theme") {
                me.Datas.ChooseCaption.TID = 0;
                me.Datas.Condition[4].C = "";
            }
            if (me.Datas.ChooseCaption.AID == 0 && me.Datas.ChooseCaption.PID == 0 && me.Datas.ChooseCaption.SID == 0 && me.Datas.ChooseCaption.BID == 0 && me.Datas.ChooseCaption.TID == 0) {
                $("#lab").css("display", "");
            }
            me.Refresh();

        } catch (e) {; }
    },
    //根据Action的数字判断更改页码
    ChangePage: function (aAction) {
        var me = Home;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Houses.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Houses.PageIndex > 1)
                    me.Datas.Houses.PageIndex = 1;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Houses.PageIndex > 1)
                    me.Datas.Houses.PageIndex--;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Houses.PageIndex < me.Datas.Houses.PageCount)
                    me.Datas.Houses.PageIndex++;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Houses.PageIndex < me.Datas.Houses.PageCount)
                    me.Datas.Houses.PageIndex = me.Datas.Houses.PageCount;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.Refresh();
        }
        catch (E) {; }
    },
    doShowRoom: function (open, aIndex) {
        var me = Home;
        try {
            if (open == 0) {
                Init.WebToast();

                var aHotel = me.Datas.Houses.DataList[aIndex];
                var aInfo = {
                    r_h_id: aHotel.h_id
                };
                Ac.acGetTable(Init.Path.Home_GetRoom, aInfo, function (aRes) {
                    if (aRes.State == 1) {
                        me.Datas.Rooms = aRes.Datas;
                        var aHtml = bt(me.Tpls.tplRoom.C, { tplData: me.Datas.Rooms });
                        hhls.fillElement(".table" + aIndex, aHtml);
                    }
                })
                $(".open" + aIndex).attr('onclick', "Home.doShowRoom(1, " + aIndex + ");")
                hhls.fillElement(".open" + aIndex, '<i class="fa fa-hand-o-up"></i> 收起');
                $("#webToast").remove();
            } else {
                $(".open" + aIndex).attr('onclick', "Home.doShowRoom(0, " + aIndex + ");")
                hhls.fillElement(".open" + aIndex, '<i class="fa fa-hand-o-down"></i> 房间');
                hhls.fillElement(".table" + aIndex, "");
            }
        } catch (e) {; }
    },
    doAddPlan: function (h_id, aIndex, r_id) {
        var me = Home;
        try {
            Init.WebToast();
            //alert(h_id + ", " + aIndex);
            var aID = "dlgAddPlan";
            me.Datas.CurHotelPlan.h_id = h_id;
            me.Datas.CurHotelPlan.r_id = r_id;
            var aInfo = {
                u_id: $("#UID").val(),
                r_id: r_id
            };
            if (aInfo.u_id == "") {
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            } else {
                var onShow = function (e) {
                    // 已经选定则显示green
                    if (me.Datas.CurPlan.length == 0) {
                        Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                            if (aRes.State == 1) {
                                me.Datas.CurPlan = aRes.Datas;
                                var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                                hhls.fillElement(".divPage", aHtml);
                                me.RefreshPlanState(r_id);
                                $("#webToast").remove();
                            }
                        })
                    } else {
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.CurPlan });
                        hhls.fillElement(".divPage", aHtml);
                        me.RefreshPlanState(r_id);
                        $("#webToast").remove();
                    }
                };
                var onHide = function (e) {
                    //me.RefreshTable();
                };
                var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
                aDlg.modal("show");
            }
        } catch (e) {; }
    },
    RefreshPlanState: function (r_id) {
        var me = Home;
        try {
            var aInfo = { jr_r_id: r_id };
            Ac.acGetTable(Init.Path.Plan_HotelPlan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    var aPlans = aRes.Datas;

                    var aPlanItems = $(".divPickOrgs .divOrg");
                    var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");
                    $.each(aPlanItems, function (aIndex, aItem) {
                        var aRole = aPlans[aIndex];
                        if (aRole.F_Chk == 1) {
                            $(aPlanItems[aIndex]).attr('onclick', "Home.doHotelPlan(" + r_id + "," + aRole.p_id + ", 0,"+ aIndex + ");")
                            $(aPlanItems[aIndex]).css("background-color", "#ECF0F5");
                            $(aPlanItem[aIndex]).css("display", "");
                            //$(aPlanItem[aIndex]).css("color", "green");
                        } else {
                            $(aPlanItems[aIndex]).attr('onclick', "Home.doHotelPlan(" + r_id + "," + aRole.p_id + ", 1,"+ aIndex + ");")
                        }
                    });

                }
            });
        } catch (e) {; }
    },
    doHotelPlan: function (r_id, p_id, aboder, aIndex) {
        var me = Home;
        try {
            var aAction = aboder ? "Plan_HotelAddPlan" : "Plan_HotelRemovePlan";
            var aPlanItems = $(".divPickOrgs .divOrg");
            var aPlanItem = $(".divPickOrgs .divOrg .divMas .checkPlan");

            $(aPlanItems[aIndex]).css("background-color", aboder ? "#ECF0F5" : "#fff");
            $(aPlanItem[aIndex]).css("display", aboder ? "" : "none");
            //$(aPlanItem[aIndex]).css("color", aboder ? "" : "green");

            if (aboder == 0) {
                $(aPlanItems[aIndex]).attr('onclick', "Home.doHotelPlan(" + r_id + "," + p_id + ", 1,"+ aIndex + ");")
            } else {
                $(aPlanItems[aIndex]).attr('onclick', "Home.doHotelPlan(" + r_id + "," + p_id + ", 0,"+ aIndex + ");")
            }
            var aInfo = {
                jr_p_id: p_id,
                jr_r_id: r_id
            };
            Common.doUserAction(aAction, aInfo, function () {

            })
        } catch (e) {; }
    },
    //查看详情
    ShowDetail: function (aIndex) {
        var me = Home;
        try {
            Init.WebToast();
            var aInfo = me.Datas.Houses.DataList[aIndex];
            if (aInfo != null) {
                var aHtml = bt(me.Tpls.tplHouseDetail.C, { tplData: aInfo });
                hhls.fillElement(".HouseDetail", aHtml);
                var aData = {
                    UID: $("#UID").val(),
                    h_id: aInfo.h_id
                };
                //判断是否已经收藏
                //Ac.acGetTable(Init.Path.Home_GetCollectState, aData, function (aRes) {
                //    if (aRes.Datas[0].F_Count == 0) {
                //        $("#webToast").remove();
                //    }
                //        //已经收藏过，更改样式，除去onclick事件
                //    else {
                //        $(".web-toast_content").text("这条旅馆信息已经在收藏中");
                //        $("#collectBtn").attr("onclick", "");
                //        $("#collectBtn").removeClass("btn-danger").addClass("btn-primary");
                //        hhls.fillElement("#collectBtn", '<i class="fa fa-heart"></i> 已收藏');
                //        Init.ClearToast("#webToast", 1)
                //    }
                //}) 
            }
            $("#webToast").remove();
            me.Datas.HouseDetail = aInfo;
        } catch (e) {; }
    },
    //加入我的收藏
    doCollect: function () {
        var me = Home;
        try {
            Init.WebToast();
            var aInfo = {
                UID: $("#UID").val(),
                h_id: me.Datas.HouseDetail.h_id
            };
            if (aInfo.UID == "") {
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            } else {
                Ac.acExecuteSql(Init.Path.Home_doCollect, aInfo, function (aRes) {
                    $(".web-toast_content").text(aRes.State == 1 ? "收藏成功！" : "收藏失败！");
                    if (aRes.State == 1) {
                        $("#collectBtn").attr("onclick", "");
                        $("#collectBtn").removeClass("btn-danger").addClass("btn-primary");
                        hhls.fillElement("#collectBtn", '<i class="fa fa-heart"></i> 已收藏');
                    } else {
                    }
                    Init.ClearToast("#webToast", 1)
                })
            }
        } catch (e) {; }
    },
    //搜索框中信息
    doSearchRefresh: function () {
        var me = Home;
        try {
            Init.WebToast();
            me.Refresh();
        } catch (e) {; }
    }
};