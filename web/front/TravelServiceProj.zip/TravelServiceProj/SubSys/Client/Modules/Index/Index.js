﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />


var Index = {
    Datas: {
        Filters: 0,
        Menus: [
            { Index: 0, Key: "", Caption: "Flight" },
            { Index: 1, Key: "", Caption: "Home" },
            { Index: 2, Key: "", Caption: "Car" },
            { Index: 3, Key: "", Caption: "Attraction" },
            { Index: 4, Key: "", Caption: "Recommend" },
            { Index: 5, Key: "", Caption: "Friend" },
        ],
        BarMenu: [
            { Index: 0, Key: "", Caption: "Flight" }, 
            { Index: 1, Key: "", Caption: "SelfCenter" },
            { Index: 2, Key: "", Caption: "SysConfig" },
        ],
        UserInfo: null
    },
    Keys: {
        UserInfoDataKey: "TravelServiceProjClent.UserInfo",
        Module: ""
    },
    Load: function () {
        var me = Index;
        try {
            me.doPickProcess(1);
        } catch (e) {; }
    },
    Refresh: function (aInfo) {
        var me = Index;
        try {
            if (aInfo == null || aInfo == "") {
                $(".spanTopUser").css("display", "none");
                $(".UnLogin").css("display", "");
                $("#labLoginUser").text("未登录");
                Flight.Load();
            }
            else {
                $(".spanTopUser").css("display", "none");
                $(".Logined").css("display", "");
                $("#labLoginUser").text("[" + aInfo.F_Code + "] " + aInfo.F_Caption);
                $("#UID").val(aInfo.F_ID);
                Flight.Load();
            }
        } catch (e) {; }
    },
    doCheckLogin: function (aCode, aPwd, aCallback) {
        var me = Index;
        try { 
            var aOnCallback = function () {
                hhls.callBack(aCallback, me.Datas.UserInfo);
            }
            Ac.acGetTable(Init.Path.Home_checkLogin, { Code: aCode, Pwd: aPwd }, function (aRes) {
                try {
                    if (aRes.Datas.length > 0) { 
                        me.Datas.UserInfo = aRes.Datas[0];
                    }
                    aOnCallback();
                }
                catch (ee) {
                    aOnCallback();
                }
            });
        }
        catch (e) {; }
    },
    doSaveUserInfo: function (aUserInfo) {
        var me = Index;
        try {
            hhls.saveLocalObj(me.Keys.UserInfoDataKey, aUserInfo);
        }
        catch (e) {; }
    },
    doLoadUserInfo: function (aCallback) {
        var me = Index;
        try {
            var aInfo = hhls.loadLocalObj(me.Keys.UserInfoDataKey);
            if (aInfo == null || aInfo == "") {
                hhls.callBack(aCallback, aInfo);
            }
            else {
                try {
                    me.doCheckLogin(aInfo.F_Code, aInfo.F_Pwd, function (aResInfo) {
                        if (aResInfo != null) {
                            me.Datas.UserInfo = aResInfo;
                        }
                        hhls.callBack(aCallback, aResInfo);
                    });
                }
                catch (ee) {
                    hhls.callBack(aCallback, aInfo);
                }
            }

        }
        catch (e) {; }
    },
    doPickProcess: function (aIndex) {
        var me = Index;
        try {
            if (me.Datas.Filters != aIndex) {
                me.Datas.Filters = aIndex;
                var aKey = me.Datas.Menus[aIndex].Caption;
                aKey += ".Load()";
                eval(aKey);
            }
        }
        catch (e) {; }
    },
    RefreshProcess: function () {
        var me = Index;
        try {
            var aIndex = Index.Datas.Filters;
            var aItems = $(".divProcess ul li");
            aItems.removeClass("active");
            $(aItems[aIndex]).addClass("active");
        }
        catch (e) {; }
    },
    OnClickMenuItem: function (aIndex) {
        var me = Index;
        try {
            if (me.Datas.UserInfo != null || aIndex == 0) {
                me.Datas.Filters = 0;
                var aItems = $("ul li");
                aItems.removeClass("active");
                $(aItems[aIndex]).addClass("active");

                var aKey = me.Datas.BarMenu[aIndex].Caption;
                aKey += ".Load()";
                eval(aKey);
            } else {
                Init.WebToast();
                $(".web-toast_content").text("请您先登录!");
                Init.ClearToast("#webToast", 1)
            }
        }
        catch (e) {; }
    }
};