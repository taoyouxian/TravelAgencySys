﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />
/// <reference path="../Home/Home.js" />


var Recommend = {
    Datas: {
        Tours: [],
        CurPlan : [],
        Filters: {
            p_days: 2,
            f_day_btime: "2018-01-04",
            f_start_addr: "北京",
            f_arrive_addr: "南京",
            p_budget: 2000,
        },
    },
    Tpls: {
        tplPlan: { P: "Modules/Recommend/tplPlan.html", C: "" },
        tplPage: { P: "Modules/Recommend/tplPage.html", C: "" },
    },
    Load: function () {
        var me = Recommend;
        try {
            Init.WebToast("数据加载中");
            hhls.GetTpls(me.Tpls, function () {
                var aHtml = me.Tpls.tplPage.C;
                hhls.fillElement("#divBody", aHtml);

                if (Index.Datas.UserInfo != null) {
                    $("#FilterPlan").css("display", "");
                    me.getPlans(function () {
                        me.Datas.CurPlan.splice(0, 0, { p_name: "全部" });
                        me.RefreshSelect(me.Datas.CurPlan, "#cmdPlan");
                        
                    });
                } else { 
                    $(".divSearch").css("display", "none");
                }
                Index.RefreshProcess();
                me.Refresh();
            });
        } catch (e) {; }
    },
    Refresh: function () {
        var me = Recommend;
        try {
            var aInfo = me.Datas.Filters;
            //Ac.acGetTable(Init.Path.Recommend_GetTour, aInfo, function (aRes) {
            $.get("http://127.0.0.1:9080/TravelServiceProj/WSDLSvr?Action=getTour", aInfo, function (data) {
                var aRes = {
                    Datas: "",
                    State: 0,
                };
                aRes.Datas = hhls.getJsonObj(data);
                aRes.State = 1;
                if (aRes.State == 1) { 
                    me.Datas.Tours = aRes.Datas;
                    me.Datas.Tours.p_budget = me.Datas.Filters.p_budget;
                    me.Datas.Tours.p_days = me.Datas.Filters.p_days;
                    var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.Tours });
                    hhls.fillElement(".HouseList", aHtml);
                }
                $("#webToast").remove();
            })
        } catch (e) {; }
    },
    RefreshSelect: function (aInfo, aElement) {
        var me = Recommend;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + i + '">' + aInfo[i].p_name + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (e) {; }
    }, 
    getPlans: function (aCallBack) {
        var me = Recommend;
        try {
            me.Datas.CurPlan = [];
            var aInfo = {
                u_id: $("#UID").val(),
            };
            Ac.acGetTable(Init.Path.Plan_Plan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    me.Datas.CurPlan = aRes.Datas;
                }
                hhls.callBack(aCallBack)
            })
        } catch (e) {; }
    },
    doSearchRefresh: function () {
        var me = Recommend;
        try {
            var aIndex = $("#cmdPlan").val() - 1;
            if (aIndex != -1) {
                me.Datas.Filters.p_days = me.Datas.CurPlan[aIndex].p_days;
                me.Datas.Filters.f_day_btime = me.Datas.CurPlan[aIndex].p_day_btime;
                me.Datas.Filters.f_start_addr = me.Datas.CurPlan[aIndex].p_start_addr;
                me.Datas.Filters.f_arrive_addr = me.Datas.CurPlan[aIndex].p_arrive_addr;
                me.Datas.Filters.p_budget = me.Datas.CurPlan[aIndex].p_budget;
            } else {
                me.Datas.Filters = {
                    p_days: 2,
                    f_day_btime: "2018-01-04",
                    f_start_addr: "北京",
                    f_arrive_addr: "南京",
                    p_budget: 2000,
                };
            }
            me.Refresh();
        } catch (e) {; }
    },
};