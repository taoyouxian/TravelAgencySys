﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../Index/Index.js" />


var SelfCenter = {
    Datas: {
        PostID: 0,
        LeftIndex: -1,
        CurPlan: [],
        Plans: [
        ],
        CurTour: null,
        PlanCosts: {
            OrderFields: "F_Cost desc", // 建立时间 
            PageSize: 3,
            PageIndex: 1,
            PageCount: [], //页数
            RowCount: [],//总数
            DataList: [],
        },
    },
    Tpls: {
        tplPage: { P: "Modules/SelfCenter/tplPage.html", C: "" },
        tplPlan: { P: "Modules/SelfCenter/tplPlan.html", C: "" },
        tplPlanDetail: { P: "Modules/SelfCenter/tplPlanDetail.html", C: "" },
    },
    Load: function () {
        var me = SelfCenter;
        try {
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        } catch (e) {; }
    },
    Refresh: function () {
        var me = SelfCenter;
        try {
            me.Datas.LeftIndex = -1;
            Init.WebToast();
            var aInfo = {
                u_id: $("#UID").val() 
            };
            Ac.acGetTable(Init.Path.Self_GetPlan, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    $("#webToast").remove();
                    me.Datas.Plans = aRes.Datas;
                    var aHtml = bt(me.Tpls.tplPage.C, { tplData: me.Datas.Plans });
                    hhls.fillElement("#divBody", aHtml);
                    if (me.Datas.Plans.length > 0) {
                        $(".Info").css("display", "none");
                    }
                    //me.doChoose(0);
                }  
            })  
        } catch (e) {; }
    },
    /*divLeftPan*/
    doChoose: function (aIndex) {
        var me = SelfCenter;
        try {
            if (aIndex != me.Datas.LeftIndex) {
                $("#txtInfo").val("");
                me.Datas.LeftIndex = aIndex;
                var aItems = $(".divLeftPanBody ul li");
                aItems.removeClass("active");
                $(aItems[me.Datas.LeftIndex]).addClass("active");


                $(".label-info").css("display", "none");
                $(".num" + aIndex).css("display", "");
                hhls.fillElement(".Ordered", '');
                me.Datas.CurPlan = me.Datas.Plans[me.Datas.LeftIndex];
                 
                Init.WebToast();

                var aInfo = {
                    u_id: $("#UID").val(),
                    p_id: me.Datas.CurPlan.p_id
                };
                Ac.acGetPageTable(Init.Path.Self_GetTourPlan, me.Datas.PlanCosts.OrderFields, me.Datas.PlanCosts.PageSize, me.Datas.PlanCosts.PageIndex, aInfo, function (aRes) {
                    if (aRes.State == 1) {
                        $("#webToast").remove();
                        me.Datas.PlanCosts = aRes.Datas;
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.PlanCosts });
                        hhls.fillElement("#divModulePage", aHtml);
                        $(".num" + aIndex).text(me.Datas.PlanCosts.PageCount);
                    }
                })
            } else {

            }
        }
        catch (E) {; }
    }, 
    doOrder: function (aIndex) {
        var me = SelfCenter;
        try {
            Init.WebToast("已经采取方案" + (aIndex + 1));
            $(".bg-purple").css("display", "none");
            var aInfo = me.Datas.PlanCosts.DataList[aIndex];
            var aPs = {
                j_p_id: aInfo.p_id,
                j_jf_id: aInfo.jf_id,
                j_jr_id: aInfo.jr_id,
                j_jc_id: aInfo.jc_id,
                j_ja_id: aInfo.ja_id,
                j_cost: aInfo.F_Cost,
            };
            Ac.acExecuteSql(Init.Path.Self_PostPlan, aPs, function (aRes) {
                Init.ClearToast("#webToast", 1)
            });
        }
        catch (E) {; }
    },
    ChangePage: function (aAction) {
        var me = SelfCenter;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.PlanCosts.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.PlanCosts.PageIndex > 1)
                    me.Datas.PlanCosts.PageIndex = 1;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.PlanCosts.PageIndex > 1)
                    me.Datas.PlanCosts.PageIndex--;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.PlanCosts.PageIndex < me.Datas.PlanCosts.PageCount)
                    me.Datas.PlanCosts.PageIndex++;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.PlanCosts.PageIndex < me.Datas.PlanCosts.PageCount)
                    me.Datas.PlanCosts.PageIndex = me.Datas.PlanCosts.PageCount;
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag) {
                var aInfo = {
                    u_id: $("#UID").val(),
                    p_id: me.Datas.CurPlan.p_id
                };
                Ac.acGetPageTable(Init.Path.Self_GetTourPlan, me.Datas.PlanCosts.OrderFields, me.Datas.PlanCosts.PageSize, me.Datas.PlanCosts.PageIndex, aInfo, function (aRes) {
                    if (aRes.State == 1) {
                        $("#webToast").remove();
                        me.Datas.PlanCosts = aRes.Datas;
                        var aHtml = bt(me.Tpls.tplPlan.C, { tplData: me.Datas.PlanCosts });
                        hhls.fillElement("#divModulePage", aHtml); 
                    }
                })
            }
        }
        catch (E) {; }
    },
    doShowDlg: function (aIndex) {
        var me = SelfCenter;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Plans[aIndex].f_id;
            var aID = "dlgPlan";
            var onShow = function (e) { 
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Plans[aIndex];
                    $("#txtCode").val(aInfo.p_code);
                    $("#txtCaption").val(aInfo.p_name);
                    $("#txtStart_addr").val(aInfo.p_start_addr);
                    $("#txtArrive_addr").val(aInfo.p_arrive_addr);
                    $("#txtBudget").val(aInfo.p_budget);
                    $("#txtDuration").val(aInfo.p_days);
                    $("#txtStart_time").val((new Date(aInfo.p_begin_time)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtArrive_time").val(new Date(aInfo.p_end_time).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtDesc").val(aInfo.p_description);
                } else { 
                    $("#txtStart_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtArrive_time").val((new Date().addDays(1)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    me.RefreshDuration();
                } 
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                //me.Refresh();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    RefreshDuration: function () {
        var me = SelfCenter;
        try {
            var date1 = new Date($("#txtStart_time").val());  //开始时间
            var date2 = new Date($("#txtArrive_time").val());    //结束时间
            var date3 = date2.getTime() - date1.getTime()  //时间差的毫秒数 
            //计算出相差天数
            var days = Math.floor(date3 / (24 * 3600 * 1000))

            //计算出小时数
            //var leave1=date3%(24*3600*1000)    //计算天数后剩余的毫秒数
            //var hours=Math.floor(leave1/(3600*1000))
            var hours = Math.floor(date3 / (3600 * 1000))
            //计算相差分钟数
            //var leave2 = leave1 % (3600 * 1000)        //计算小时数后剩余的毫秒数
            var leave2 = date3 % (3600 * 1000)        //计算小时数后剩余的毫秒数
            var minutes = Math.floor(leave2 / (60 * 1000))
            ////计算相差秒数
            //var leave3 = leave2 % (60 * 1000)      //计算分钟数后剩余的毫秒数
            //var seconds = Math.round(leave3 / 1000)
            //alert(" 相差 " + days + "天 " + hours + "小时 " + minutes + " 分钟" + seconds + " 秒") 

            $("#txtDuration").val(days);
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = SelfCenter;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Plan_New : Init.Path.Plan_Edit;
            var aPs = {
                code: $("#txtCode").val(),
                name: $("#txtCaption").val(),
                start_addr: $("#txtStart_addr").val(),
                arrive_addr: $("#txtArrive_addr").val(),
                begin_time: $("#txtStart_time").val(),
                end_time: $("#txtArrive_time").val(),
                budget: $("#txtBudget").val(),
                days: $("#txtDuration").val(),
                description: $("#txtDesc").val(),
                u_id: Index.Datas.UserInfo.F_ID,
                id: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgPlan").modal("toggle");
                    me.Refresh();
                }
                else {
                    alert("Save failed!");
                }
            });
        }
        catch (e) {; }
    },
};