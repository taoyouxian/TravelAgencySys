﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />

var AttractionManage = {
    Datas: {
        Levels: {
            Index: 0,
            Items: []
        },
        PostID: 0,
        ParentAttractions: [],
        Attractions: {
            OrderFields: "a_id desc",
            PageSize: 10,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
    },
    Tpls: {
        tplPage: { P: "Modules/AttractionManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/AttractionManage/tplTableItem.htm", C: "" },
        tplPageFooter: { P: "Modules/AttractionManage/tplPageFooter.htm", C: "" }
    },
    Load: function () {
        var me = AttractionManage;
        try {
            doSetCurLeftMenu(3);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = AttractionManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);

            $("#tBodyTr").html(Init.Utility.Loading);

            me.RefreshTable();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = AttractionManage;
        try {
            $("#lstAttractionLevels li").removeClass("active");
            $($("#lstAttractionLevels li")[me.Datas.Levels.Index]).addClass("active");
            var aPs = { AttractionLevel: me.Datas.Levels.Index };
            Ac.acGetPageTable(Init.Path.Attraction_Attractions, me.Datas.Attractions.OrderFields, me.Datas.Attractions.PageSize, me.Datas.Attractions.PageIndex, aPs, function (aRes) {
                $("#webToast").remove();
                me.Datas.Attractions = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Attractions });
                hhls.fillElement("#tBodyAttractions", aHtml);
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Attractions });
                hhls.fillElement(".divPagingOutter", aHtml);
            });
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = AttractionManage;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Attractions.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Attractions.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Attractions.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Attractions.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Attractions.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Attractions.PageIndex < me.Datas.Attractions.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Attractions.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Attractions.PageIndex < me.Datas.Attractions.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Attractions.PageIndex = me.Datas.Attractions.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 5) {
                var aPageNum = $(".txtPageNum").val();
                if (me.Datas.Attractions.PageIndex < aPageNum && aPageNum < me.Datas.Attractions.PageCount)
                    me.Datas.Attractions.PageIndex = aPageNum;
                else {
                    flag = true;
                    $(".web-toast_content").text("请输入符合的页码");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.RefreshTable();
        }
        catch (E) {; }
    },
    doOnPickAttractionLevel: function (aIndex) {
        var me = AttractionManage;
        try {
            me.Datas.Levels.Index = aIndex;
            me.RefreshTable();
        }
        catch (e) {; }
    },
    doShowDlg: function (aIndex) {
        var me = AttractionManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Attractions.DataList[aIndex].a_id;
            var aID = "dlgAttractionManage";
            var onShow = function (e) {
                //Ac.acGetTable(Init.Path.Attraction_ParentAttractions, {}, function (aRes) {
                //    me.Datas.ParentAttractions = aRes.Datas;
                //    hhls.assignSelect("#cmbParentID", me.Datas.ParentAttractions, "a_id", "F_Caption");
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Attractions.DataList[aIndex];
                    $("#txtLocation").val(aInfo.a_location);
                    $("#txtTour_type").val(aInfo.a_tour_type);
                    $("#txtTour").val(aInfo.a_tour);
                } else {

                }
                //});
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = AttractionManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Attraction_New : Init.Path.Attraction_Edit;
            var aPs = {
                location: $("#txtLocation").val(),
                tour_type: $("#txtTour_type").val(),
                tour: $("#txtTour").val(),
                id: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgAttractionManage").modal("toggle");
                }
                else {
                    alert("Save failed!");
                }
            });
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = AttractionManage;
        try {
            var aFlag = window.confirm("Are you sure to delete?");
            if (aFlag) {
                var aPs = { id: me.Datas.Attractions.DataList[aIndex].a_id };
                Ac.acExecuteSql(Init.Path.Attraction_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        me.RefreshTable();
                    }
                    else {
                        alert("Delete failed!");
                    }
                });
            }
        }
        catch (e) {; }
    }
};
