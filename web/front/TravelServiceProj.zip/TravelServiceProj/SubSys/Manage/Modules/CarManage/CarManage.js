﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />

var CarManage = {
    Datas: {
        Dicts : {
            Seat: [],
            Price: [],
            Preference: [],
            Transmission: [],
            Type: [],
        },
        PostID: 0,
        CarID: null,
        Cars: {
            OrderFields: "c_id desc",
            PageSize: 10,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
    },
    Tpls: {
        tplPage: { P: "Modules/CarManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/CarManage/tplTableItem.htm", C: "" },
        tplPageFooter: { P: "Modules/CarManage/tplPageFooter.htm", C: "" }
    },
    Load: function () {
        var me = CarManage;
        try {
            doSetCurLeftMenu(2);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = CarManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);

            $("#tBodyTr").html(Init.Utility.Loading);

            me.RefreshTable();
            me.RefreshDicts();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = CarManage;
        try {
            var aPs = { };
            Ac.acGetPageTable(Init.Path.Car_Cars, me.Datas.Cars.OrderFields, me.Datas.Cars.PageSize, me.Datas.Cars.PageIndex, aPs, function (aRes) {
                $("#webToast").remove();
                me.Datas.Cars = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Cars });
                hhls.fillElement("#tBodyCars", aHtml);
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Cars });
                hhls.fillElement(".divPagingOutter", aHtml);
            });
        }
        catch (e) {; }
    },
    RefreshDicts: function () {
        var me = CarManage;
        try {
            var aTables = {
                Seat: Init.Path.Dicts_Seat,
                Price: Init.Path.Dicts_Price,
                Preference: Init.Path.Dicts_Preference,
                Transmission: Init.Path.Dicts_Transmission,
                Type: Init.Path.Dicts_Type,
            };
            Ac.acGetDs(aTables, {}, function (aRes) {
                me.Datas.Dicts.Seat = aRes.Datas.Seat;
                me.Datas.Dicts.Price = aRes.Datas.Price;
                me.Datas.Dicts.Preference = aRes.Datas.Preference;
                me.Datas.Dicts.Transmission = aRes.Datas.Transmission;
                me.Datas.Dicts.Type = aRes.Datas.Type;
            });
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = CarManage;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Cars.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Cars.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Cars.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Cars.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Cars.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Cars.PageIndex < me.Datas.Cars.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Cars.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Cars.PageIndex < me.Datas.Cars.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Cars.PageIndex = me.Datas.Cars.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 5) {
                var aPageNum = $(".txtPageNum").val();
                if (me.Datas.Cars.PageIndex < aPageNum && aPageNum < me.Datas.Cars.PageCount)
                    me.Datas.Cars.PageIndex = aPageNum;
                else {
                    flag = true;
                    $(".web-toast_content").text("请输入符合的页码");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.RefreshTable();
        }
        catch (E) {; }
    },
    doShowDlg: function (aIndex) {
        var me = CarManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Cars.DataList[aIndex].c_id;
            var aID = "dlgCarManage";
            var onShow = function (e) {
                me.RefreshSelect(me.Datas.Dicts.Type, "#cmbType");
                me.RefreshSelect(me.Datas.Dicts.Preference, "#cmbPreference");
                me.RefreshSelect(me.Datas.Dicts.Price, "#cmbPrice");
                me.RefreshSelect(me.Datas.Dicts.Seat, "#cmbSeat");
                me.RefreshSelect(me.Datas.Dicts.Transmission, "#cmbTransmission");

                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Cars.DataList[aIndex];
                    $("#txtLease_addr").val(aInfo.c_lease_addr);
                    $("#txtReturn_addr").val(aInfo.c_return_addr);
                    $("#txtLease_time").val((new Date(aInfo.c_lease_time)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtReturn_time").val(new Date(aInfo.c_return_time).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtRecommend_com").val(aInfo.c_recommend_com);
                    $("#txtDaily_price").val(aInfo.c_daily_price);

                    $("#cmbType").val(me.Datas.Dicts.Type[aInfo.c_ty_id - 1].F_ID);
                    $("#cmbPrice").val(me.Datas.Dicts.Price[aInfo.c_pri_id - 1].F_ID);
                    $("#cmbPreference").val(me.Datas.Dicts.Preference[aInfo.c_pre_id - 1].F_ID);
                    $("#cmbSeat").val(me.Datas.Dicts.Seat[aInfo.c_s_id - 1].F_ID);
                    $("#cmbTransmission").val(me.Datas.Dicts.Transmission[aInfo.c_tr_id - 1].F_ID);
                } else {
                    $("#txtLease_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtReturn_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                }
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = CarManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Car_New : Init.Path.Car_Edit;
            var aPs = {
                lease_addr: $("#txtLease_addr").val(),
                return_addr: $("#txtReturn_addr").val(),
                lease_time: $("#txtLease_time").val(),
                return_time: $("#txtReturn_time").val(),
                recommend_com: $("#txtRecommend_com").val(),
                daily_price: $("#txtDaily_price").val(),
                price: $("#txtPrice").val(),
                s_id: $("#cmbSeat").val(),
                pre_id: $("#cmbPreference").val(),
                pri_id: $("#cmbPrice").val(),
                ty_id: $("#cmbType").val(),
                tr_id: $("#cmbTransmission").val(),
                id: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgCarManage").modal("toggle");
                }
                else {
                    alert("Save failed!");
                }
            });
        }
        catch (e) {; }
    },
    RefreshSelect: function (aInfo, aElement) {
        var me = HotelManage;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_ID + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = CarManage;
        try {
            var aFlag = window.confirm("Are you sure to delete?");
            if (aFlag) {
                var aPs = { id: me.Datas.Cars.DataList[aIndex].c_id };
                Ac.acExecuteSql(Init.Path.Car_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        me.RefreshTable();
                    }
                    else {
                        alert("Delete failed!");
                    }
                });
            }
        }
        catch (e) {; }
    },
};
