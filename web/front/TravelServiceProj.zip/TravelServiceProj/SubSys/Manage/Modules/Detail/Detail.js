﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var Detail = {
    Datas: {
        Records: {
            OrderFields: "F_ID desc",
            PageSize: 9,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
        DetailInfo: {
            RecordInfo: {},
            RecordReply: {},
            RecordJudge: {},
            RecordAction: [],
        },
        curIndex : -1,
    },
    Tpls: {
        tplPage: { P: "Modules/Detail/tplPage.htm", C: "" },
        tplList: { P: "Modules/Detail/tplList.htm", C: "" },
        tplPageFooter: { P: "Modules/Detail/tplPageFooter.htm", C: "" },
    },
    Load: function () {
        var me = Detail;
        try {
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = Detail;
        try {

        }
        catch (e) {; }
    },
    onShowDetail: function (aIndex) {
        var me = Detail;
        try {
            if (me.Datas.curIndex != aIndex) { 
                var aItems = $("ul.lstFilters li");
                aItems.removeClass("active");
                $(".divContents").html("<div class='ibox'><div class='ibox-content'><div class='sk-spinner sk-spinner-three-bounce'><div class='sk-bounce1'></div><div class='sk-bounce2'></div><div class='sk-bounce3'></div></div></div></div>");
                me.Datas.curIndex = aIndex;
                me.Datas.DetailInfo.RecordInfo = me.Datas.Records.DataList[aIndex];
                var aHashed_id = me.Datas.Records.DataList[aIndex].hashed_id;
                $("#txtHashed_id").val(aHashed_id);
                me.GetDatas(aHashed_id, function () {
                    var aHtml = bt(me.Tpls.tplPage.C, { tplData: me.Datas.DetailInfo });
                    hhls.fillElement(".divContents", aHtml);
                    me.doOnPickSection(0);
                });
            } else { 
                Init.Web_Toast("已经在搜索当前报单", 1);
            }
        }
        catch (e) {; }
    },
    GetDatas: function (aHashed_id, aCallback) {
        var me = Detail;
        try {
            var aPs = { hashed_id: aHashed_id };
            var aTables = {
                RecordReply: Init.Path.Detail_RecordReply,
                RecordJudge: Init.Path.Detail_RecordJudge,
                RecordAction: Init.Path.Detail_RecordAction,
            };
            Ac.acGetDs(aTables, aPs, function (aRes) {
                me.Datas.DetailInfo.RecordInfo.Keywords = hhls.getJsonObj(me.Datas.DetailInfo.RecordInfo.F_Keywords);
                if (me.Datas.DetailInfo.RecordInfo.F_Medias != []) {
                    me.Datas.DetailInfo.RecordInfo.Medias = hhls.getJsonObj(me.Datas.DetailInfo.RecordInfo.F_Medias);
                    var aImgs = me.Datas.DetailInfo.RecordInfo.Medias.Imgs;
                    me.Datas.DetailInfo.RecordInfo.Imgs = [];
                    $.each(aImgs, function (aInd, aItem) {
                        var aUrl = Init.Datas.MediaPath + Common.Config.DataSvc.WxSrc + "/" + aItem.Sid + ".jpg";
                        me.Datas.DetailInfo.RecordInfo.Imgs.push(aUrl);
                    });
                    var aVoices = me.Datas.DetailInfo.RecordInfo.Medias.Voices.Voices;
                    me.Datas.DetailInfo.RecordInfo.Voices = [];
                    $.each(aVoices, function (aInd, aItem) {
                        me.Datas.DetailInfo.RecordInfo.Voices.push(aItem);
                    });
                }

                me.Datas.DetailInfo.RecordReply = aRes.Datas.RecordReply.length > 0 ? aRes.Datas.RecordReply[0] : null;
                if (me.Datas.DetailInfo.RecordReply != null) {
                    me.Datas.DetailInfo.RecordReply.Medias = hhls.getJsonObj(me.Datas.DetailInfo.RecordReply.F_Medias);
                    var aImgs = me.Datas.DetailInfo.RecordReply.Medias.Imgs;
                    me.Datas.DetailInfo.RecordReply.Imgs = [];
                    $.each(aImgs, function (aInd, aItem) {
                        var aUrl = Init.Datas.MediaPath + Common.Config.DataSvc.WxSrc + "/" + aItem.Sid + ".jpg";
                        me.Datas.DetailInfo.RecordReply.Imgs.push(aUrl);
                    });
                    var aVoices = me.Datas.DetailInfo.RecordReply.Medias.Contents.Voices;
                    me.Datas.DetailInfo.RecordReply.Voices = [];
                    $.each(aVoices, function (aInd, aItem) {
                        me.Datas.DetailInfo.RecordReply.Voices.push(aItem);
                    });
                }

                me.Datas.DetailInfo.RecordJudge = aRes.Datas.RecordJudge.length > 0 ? aRes.Datas.RecordJudge[0] : null;
                if (me.Datas.DetailInfo.RecordJudge != null) {
                    me.Datas.DetailInfo.RecordJudge.Medias = hhls.getJsonObj(me.Datas.DetailInfo.RecordJudge.F_Medias);
                    var aImgs = me.Datas.DetailInfo.RecordJudge.Medias.Imgs;
                    me.Datas.DetailInfo.RecordJudge.Imgs = [];
                    $.each(aImgs, function (aInd, aItem) {
                        var aUrl = Init.Datas.MediaPath + Common.Config.DataSvc.WxSrc + "/" + aItem.Sid + ".jpg";
                        me.Datas.DetailInfo.RecordJudge.Imgs.push(aUrl);
                    });
                    var aVoices = me.Datas.DetailInfo.RecordJudge.Medias.Contents.Voices;
                    me.Datas.DetailInfo.RecordJudge.Voices = [];
                    $.each(aVoices, function (aInd, aItem) {
                        me.Datas.DetailInfo.RecordJudge.Voices.push(aItem);
                    });
                }

                me.Datas.DetailInfo.RecordAction = aRes.Datas.RecordAction;
                hhls.callBack(aCallback);
            });
        }
        catch (e) {; }
    },
    onSearch: function () {
        var me = Detail;
        try {
            Init.WebToast();
            me.getFilters();
        }
        catch (e) {; }
    },
    getFilters: function () {
        var me = Detail;
        try {
            var aHashed_id = $("#txtHashed_id").val();
            Ac.acGetPageTable(Init.Path.Detail_Records, me.Datas.Records.OrderFields, me.Datas.Records.PageSize, me.Datas.Records.PageIndex, { hashed_id: aHashed_id }, function (aRes) {
                $("#webToast").remove();
                me.Datas.Records = aRes.Datas;
                var aHtml = null;
                $(".RecordList").empty();
                if (me.Datas.Records.DataList.length > 0) {
                    aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Records });
                    hhls.fillElement(".RecordList", aHtml);
                }
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Records });
                hhls.fillElement(".divPagingOutter", aHtml);
                Init.LoadWxImg();
                if (me.Datas.Records.PageCount == 1) {
                    me.onShowDetail(0);
                }
            });
        }
        catch (e) {; }
    },
    doOnPickSection: function (aIndex) {
        var me = Detail;
        try {
            var aSections = $(".divContents .divSection");
            aSections.css("display", "none");
            var aItems = $("ul.lstFilters li");
            aItems.removeClass("active");
            $(aItems[aIndex]).addClass("active");
            var aSection = $(aSections[aIndex])
            aSection.css("display", "inline");
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = Detail;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Records.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Records.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Records.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Records.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Records.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Records.PageIndex < me.Datas.Records.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Records.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Records.PageIndex < me.Datas.Records.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Records.PageIndex = me.Datas.Records.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            //else if (aAction == 5) {
            //    var aPageNum = $(".txtPageNum").val();
            //    if (me.Datas.Records.PageIndex < aPageNum && aPageNum < me.Datas.Records.PageCount)
            //        me.Datas.Records.PageIndex = aPageNum;
            //    else {
            //        flag = true;
            //        $(".web-toast_content").text("请输入符合的页码");
            //        Init.ClearToast("#webToast", 1)
            //    }
            //}
            if (!flag)
                me.getFilters();
        }
        catch (E) {; }
    },
};
