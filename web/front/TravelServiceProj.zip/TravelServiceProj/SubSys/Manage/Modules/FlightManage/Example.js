﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../../../../Commons/Common.js" />


$("#login_tab1").click(function () {
    refresh(1);
});
$("#login_tab2").click(function () {
    refresh(2);
});
$("#login_tab3").click(function () {
    refresh(3);
});

var menu = [1, 2, 3];

function doSetMenu(aIndex) {
    try {
        $("#login_t" + aIndex).css("display", "");
        for (x in a) {
            if(x != aIndex)
                $("#login_t" + x).css("display", "none");
        }
        var aItems = $("ul li");
        aItems.removeClass("login_hover");
        $(aItems[aIndex]).addClass("login_hover");
    }
    catch (e) {; }
}