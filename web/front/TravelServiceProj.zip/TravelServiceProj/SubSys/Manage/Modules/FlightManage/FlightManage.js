﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Init.js" />
/// <reference path="../../../../Commons/Common.js" />

var FlightManage = {
    Datas: {
        Levels: {
            Index: 0,
            Items: []
        },
        PostID: 0,
        FlightID: null,
        ParentFlights: [],
        Flights: {
            OrderFields: "f_id desc",
            PageSize: 10,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
    },
    Tpls: {
        tplPage: { P: "Modules/FlightManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/FlightManage/tplTableItem.htm", C: "" },
        tplPageFooter: { P: "Modules/FlightManage/tplPageFooter.htm", C: "" },
        tplDlgValueItem: { P: "Modules/FlightManage/tplDlgValueItem.htm", C: "" }, 
    },
    Load: function () {
        var me = FlightManage;
        try {
            doSetCurLeftMenu(0);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = FlightManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);

            $("#tBodyTr").html(Init.Utility.Loading);

            me.RefreshTable();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = FlightManage;
        try {
            $("#lstFlightLevels li").removeClass("active");
            $($("#lstFlightLevels li")[me.Datas.Levels.Index]).addClass("active");
            var aPs = { FlightLevel: me.Datas.Levels.Index };
            Ac.acGetPageTable(Init.Path.Flight_Flights, me.Datas.Flights.OrderFields, me.Datas.Flights.PageSize, me.Datas.Flights.PageIndex, aPs, function (aRes) {
                $("#webToast").remove();
                me.Datas.Flights = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Flights });
                hhls.fillElement("#tBodyFlights", aHtml);
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Flights });
                hhls.fillElement(".divPagingOutter", aHtml);
            });
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = FlightManage;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Flights.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Flights.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Flights.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Flights.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Flights.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Flights.PageIndex < me.Datas.Flights.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Flights.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Flights.PageIndex < me.Datas.Flights.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Flights.PageIndex = me.Datas.Flights.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 5) {
                var aPageNum = $(".txtPageNum").val();
                if (me.Datas.Flights.PageIndex < aPageNum && aPageNum < me.Datas.Flights.PageCount)
                    me.Datas.Flights.PageIndex = aPageNum;
                else {
                    flag = true;
                    $(".web-toast_content").text("请输入符合的页码");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.RefreshTable();
        }
        catch (E) {; }
    },
    doOnPickFlightLevel: function (aIndex) {
        var me = FlightManage;
        try {
            me.Datas.Levels.Index = aIndex;
            me.RefreshTable();
        }
        catch (e) {; }
    },
    doShowDlg: function (aIndex) {
        var me = FlightManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Flights.DataList[aIndex].f_id;
            var aID = "dlgFlightManage";
            var onShow = function (e) {
                //Ac.acGetTable(Init.Path.Flight_ParentFlights, {}, function (aRes) {
                //    me.Datas.ParentFlights = aRes.Datas;
                //    hhls.assignSelect("#cmbParentID", me.Datas.ParentFlights, "f_id", "F_Caption");
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Flights.DataList[aIndex];
                    $("#txtCode").val(aInfo.f_code);
                    $("#txtCaption").val(aInfo.f_caption);
                    $("#txtStart_addr").val(aInfo.f_start_addr);
                    $("#txtArrive_addr").val(aInfo.f_arrive_addr);
                    $("#txtPrice").val(aInfo.f_price);
                    $("#txtDuration").val(aInfo.f_duration);
                    $("#txtDuration_info").val(aInfo.f_duration_info);
                    $("#txtStart_time").val((new Date(aInfo.f_start_time)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtArrive_time").val(new Date(aInfo.f_arrive_time).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                } else {
                    //$('.txtDt').datetimepicker({
                    //    language: 'zh-CN',
                    //    minView: "month", //选择日期后，不会再跳转去选择时分秒 
                    //    format: "yyyy-MM-dd HH:mm",
                    //    weekStart: 1,
                    //    todayBtn: 1,
                    //    autoclose: 1,
                    //    todayHighlight: 1,
                    //    startView: 2,
                    //    forceParse: 0,
                    //    showMeridian: 1
                    //}).on('changeDate', function (ev) {
                    //    $(this).datetimepicker('hide');
                    //});
                    $("#txtStart_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    //$("#txtStart_Time").val((new Date().addDays(-6)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtArrive_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    me.RefreshDuration();
                }
                //});
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    RefreshDuration: function () {
        var me = FlightManage;
        try {
            var date1 = new Date($("#txtStart_time").val());  //开始时间
            var date2 = new Date($("#txtArrive_time").val());    //结束时间
            var date3 = date2.getTime()-date1.getTime()  //时间差的毫秒数 
            //计算出相差天数
            var days=Math.floor(date3/(24*3600*1000))
 
            //计算出小时数
            //var leave1=date3%(24*3600*1000)    //计算天数后剩余的毫秒数
            //var hours=Math.floor(leave1/(3600*1000))
            var hours = Math.floor(date3 / (3600 * 1000))
            //计算相差分钟数
            //var leave2 = leave1 % (3600 * 1000)        //计算小时数后剩余的毫秒数
            var leave2 = date3 % (3600 * 1000)        //计算小时数后剩余的毫秒数
            var minutes = Math.floor(leave2 / (60 * 1000))
            ////计算相差秒数
            //var leave3 = leave2 % (60 * 1000)      //计算分钟数后剩余的毫秒数
            //var seconds = Math.round(leave3 / 1000)
            //alert(" 相差 " + days + "天 " + hours + "小时 " + minutes + " 分钟" + seconds + " 秒")
            $("#txtDuration").val(hours + ":" + minutes);

            $("#txtDuration_info").val(days + " days arrival");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = FlightManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Flight_New : Init.Path.Flight_Edit;
            var aPs = {
                code: $("#txtCode").val(),
                caption: $("#txtCaption").val(),
                start_addr: $("#txtStart_addr").val(),
                arrive_addr: $("#txtArrive_addr").val(),
                start_time: $("#txtStart_time").val(),
                arrive_time: $("#txtArrive_time").val(),
                price: $("#txtPrice").val(),
                duration: $("#txtDuration").val(),
                duration_info: $("#txtDuration_info").val(),
                id: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgFlightManage").modal("toggle");
                }
                else {
                    alert("Save failed!");
                }
            });
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = FlightManage;
        try {
            var aFlag = window.confirm("Are you sure to delete?");
            if (aFlag) {
                var aPs = { id: me.Datas.Flights.DataList[aIndex].f_id };
                Ac.acExecuteSql(Init.Path.Flight_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        me.RefreshTable();
                    }
                    else {
                        alert("Delete failed!");
                    }
                });
            }
        }
        catch (e) {; }
    },
    doFlightKeyValues: function (aIndex) {
        var me = FlightManage;
        try {
            me.Datas.FlightID = me.Datas.Flights.DataList[aIndex].f_id;
            var aID = "dlgFightKeyValues";
            var onShow = function (e) {
                me.RefreshKeyValues();
            };
            var onHide = function (e) { 
                //alert(1);
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    RefreshKeyValues: function () {
        var me = FlightManage;
        try {
            Ac.acGetTable(Init.Path.Seat_Seats, { fid: me.Datas.FlightID }, function (aRes) {
                var aInfo = aRes.Datas;
                if (aRes.State == 1 && aInfo != null) {
                    var aHtml = bt(me.Tpls.tplDlgValueItem.C, { tplData: aInfo });
                    hhls.fillElement("#divValueItems", aHtml);
                }
            });
        }
        catch (e) {; }
    },
    doAddKeyValues: function () {
        var me = FlightManage;
        try {
            var aAction = "Seat_New";
            var aPs = {
                num: $("#txtNum").val(),
                type: $("#txtType").val(),
                daily_price: $("#txtDaily_price").val(),
                fid: me.Datas.FlightID
            };
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Save failed!');
                }
            })
        }
        catch (e) {; }
    },
    doUpdateKeyValues: function (aIndex, aID) {
        var me = FlightManage;
        try {
            var aPs = {
                //fid: me.Datas.FlightID,
                id: aID,
                type: $($(".txtType")[aIndex]).val(),
                num: $($(".txtNum")[aIndex]).val(),
                daily_price: $($(".txtDaily_price")[aIndex]).val(),
            };
            var aAction = "Seat_Edit";
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Update failed!');
                }
            })
        }
        catch (cee) {; }
    },
    doDeleteKeyValues: function (aID) {
        var me = FlightManage;
        try {
            var aPs = {
                id : aID, 
            };
            var aAction = "Seat_Delete";
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Delete failed!');
                }
            })
        }
        catch (cee) {; }
    },
};
