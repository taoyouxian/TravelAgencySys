﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />
/// <reference path="../../../../Commons/Init.js" />

var HotelManage = {
    Datas: {
        Dicts : {
            Addr: [],
            Price: [],
            Star: [],
            Brand: [],
            Theme: [],
        },
        PostID: 0,
        HotelID: null,
        HotelCode: null,
        Hotels: {
            OrderFields: "h_id desc",
            PageSize: 10,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
    },
    Tpls: {
        tplPage: { P: "Modules/HotelManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/HotelManage/tplTableItem.htm", C: "" },
        tplPageFooter: { P: "Modules/HotelManage/tplPageFooter.htm", C: "" },
        tplDlgValueItem: { P: "Modules/HotelManage/tplDlgValueItem.htm", C: "" },
    },
    Load: function () {
        var me = HotelManage;
        try {
            doSetCurLeftMenu(1);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = HotelManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);

            $("#tBodyTr").html(Init.Utility.Loading);

            me.RefreshTable();
            me.RefreshDicts();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = HotelManage;
        try {
            var aPs = {};
            Ac.acGetPageTable(Init.Path.Hotel_Hotels, me.Datas.Hotels.OrderFields, me.Datas.Hotels.PageSize, me.Datas.Hotels.PageIndex, aPs, function (aRes) {
                $("#webToast").remove();
                me.Datas.Hotels = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Hotels });
                hhls.fillElement("#tBodyHotels", aHtml);
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Hotels });
                hhls.fillElement(".divPagingOutter", aHtml);
            });
        }
        catch (e) {; }
    },
    RefreshDicts: function () {
        var me = HotelManage;
        try {
            var aTables = {
                Addr: Init.Path.Dict_Addr,
                Price: Init.Path.Dict_Price,
                Star: Init.Path.Dict_Star,
                Brand: Init.Path.Dict_Brand,
                Theme: Init.Path.Dict_Theme,
            };
            Ac.acGetDs(aTables, {}, function (aRes) {
                me.Datas.Dicts.Addr = aRes.Datas.Addr;
                me.Datas.Dicts.Price = aRes.Datas.Price;
                me.Datas.Dicts.Star = aRes.Datas.Star;
                me.Datas.Dicts.Brand = aRes.Datas.Brand;
                me.Datas.Dicts.Theme = aRes.Datas.Theme;
            });
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = HotelManage;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Hotels.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Hotels.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Hotels.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Hotels.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Hotels.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Hotels.PageIndex < me.Datas.Hotels.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Hotels.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Hotels.PageIndex < me.Datas.Hotels.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Hotels.PageIndex = me.Datas.Hotels.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 5) {
                var aPageNum = $(".txtPageNum").val();
                if (me.Datas.Hotels.PageIndex < aPageNum && aPageNum < me.Datas.Hotels.PageCount)
                    me.Datas.Hotels.PageIndex = aPageNum;
                else {
                    flag = true;
                    $(".web-toast_content").text("请输入符合的页码");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.RefreshTable();
        }
        catch (E) {; }
    },
    doShowDlg: function (aIndex) {
        var me = HotelManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Hotels.DataList[aIndex].h_id;
            var aID = "dlgHotelManage";
            var onShow = function (e) {
                //Ac.acGetTable(Init.Path.Hotel_ParentHotels, {}, function (aRes) {
                //    me.Datas.ParentHotels = aRes.Datas;
                //    hhls.assignSelect("#cmbParentID", me.Datas.ParentHotels, "h_id", "F_Caption");

                me.RefreshSelect(me.Datas.Dicts.Addr, "#cmbAddr");
                me.RefreshSelect(me.Datas.Dicts.Price, "#cmbPrice");
                me.RefreshSelect(me.Datas.Dicts.Star, "#cmbStar");
                me.RefreshSelect(me.Datas.Dicts.Brand, "#cmbBrand");
                me.RefreshSelect(me.Datas.Dicts.Theme, "#cmbTheme");

                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Hotels.DataList[aIndex];
                    $("#txtName").val(aInfo.h_name);
                    $("#txtCode").val(aInfo.h_code);
                    $("#txtStart_time").val((new Date(aInfo.h_start_time)).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtEnd_time").val(new Date(aInfo.h_end_time).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtCity").val(aInfo.h_city);
                    $("#txtPrice").val(aInfo.h_price);

                    $("#cmbAddr").val(me.Datas.Dicts.Addr[aInfo.h_a_id - 1].F_ID);
                    $("#cmbPrice").val(me.Datas.Dicts.Price[aInfo.h_p_id - 1].F_ID);
                    $("#cmbStar").val(me.Datas.Dicts.Star[aInfo.h_s_id - 1].F_ID);
                    $("#cmbBrand").val(me.Datas.Dicts.Brand[aInfo.h_b_id - 1].F_ID);
                    $("#cmbTheme").val(me.Datas.Dicts.Theme[aInfo.h_t_id - 1].F_ID);
                } else {
                    $("#txtStart_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                    $("#txtEnd_time").val((new Date()).toString("yyyy-MM-dd HH:mm")).datetimepicker("update");
                }
                //});
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = HotelManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Hotel_New : Init.Path.Hotel_Edit;
            var aPs = {
                name: $("#txtName").val(),
                code: $("#txtCode").val(),
                start_time: $("#txtStart_time").val(),
                end_time: $("#txtEnd_time").val(),
                city: $("#txtCity").val(),
                price: $("#txtPrice").val(),
                t_id: $("#cmbTheme").val(),
                s_id: $("#cmbStar").val(),
                p_id: $("#cmbPrice").val(),
                b_id: $("#cmbBrand").val(),
                a_id: $("#cmbAddr").val(),
                id: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgHotelManage").modal("toggle");
                }
                else {
                    alert("Save failed!");
                }
            });
        }
        catch (e) {; }
    },
    RefreshSelect: function (aInfo, aElement) {
        var me = HotelManage;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_ID + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = HotelManage;
        try {
            var aFlag = window.confirm("Are you sure to delete?");
            if (aFlag) {
                var aPs = { id: me.Datas.Hotels.DataList[aIndex].h_id };
                Ac.acExecuteSql(Init.Path.Hotel_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        me.RefreshTable();
                    }
                    else {
                        alert("Delete failed!");
                    }
                });
            }
        }
        catch (e) {; }
    },
    doHotelKeyValues: function (aIndex) {
        var me = HotelManage;
        try {
            me.Datas.HotelID = me.Datas.Hotels.DataList[aIndex].h_id;
            me.Datas.HotelCode = me.Datas.Hotels.DataList[aIndex].h_code;
            var aID = "dlgHotelKeyValues";
            var onShow = function (e) {
                me.RefreshKeyValues();
            };
            var onHide = function (e) {
                //alert(1);
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    RefreshKeyValues: function () {
        var me = HotelManage;
        try {
            Ac.acGetTable(Init.Path.Room_Rooms, { hid: me.Datas.HotelID }, function (aRes) {
                var aInfo = aRes.Datas;
                if (aRes.State == 1 && aInfo != null) {
                    var aHtml = bt(me.Tpls.tplDlgValueItem.C, { tplData: aInfo });
                    hhls.fillElement("#divValueItems", aHtml);
                    $("#txtH_code").text(me.Datas.HotelCode);
                }
            });
        }
        catch (e) {; }
    },
    doAddKeyValues: function () {
        var me = HotelManage;
        try {
            var aAction = "Room_New";
            var aPs = {
                r_code: $("#txtR_code").val(),
                type: $("#txtType").val(),
                bed: $("#txtBed").val(),
                cancel: $("#txtCancel").val(),
                eat: $("#txtEat").val(),
                wifi: $("#txtWifi").val(),
                daily_price: $("#txtDaily_price").val(),
                hid: me.Datas.HotelID
            };
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Save failed!');
                }
            })
        }
        catch (e) {; }
    },
    doUpdateKeyValues: function (aIndex, aID) {
        var me = HotelManage;
        try {
            var aPs = {
                id: aID,
                r_code: $($(".txtCode")[aIndex]).val(),
                type: $($(".txtType")[aIndex]).val(),
                bed: $($(".txtBed")[aIndex]).val(),
                cancel: $($(".txtCancel")[aIndex]).val(),
                eat: $($(".txtEat")[aIndex]).val(),
                wifi: $($(".txtWifi")[aIndex]).val(),
                daily_price: $($(".txtDaily_price")[aIndex]).val()
            };
            var aAction = "Room_Edit";
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Update failed!');
                }
            })
        }
        catch (cee) {; }
    },
    doDeleteKeyValues: function (aID) {
        var me = HotelManage;
        try {
            var aPs = {
                id: aID,
            };
            var aAction = "Room_Delete";
            Common.doUserAction(aAction, aPs, function (aRes) {
                if (aRes.State == 1) {
                    me.RefreshKeyValues();
                }
                else {
                    alert('Delete failed!');
                }
            })
        }
        catch (cee) {; }
    },
};
