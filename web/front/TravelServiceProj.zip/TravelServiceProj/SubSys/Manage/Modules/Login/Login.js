﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var Login = {
    Datas: {
        t1: null,
        OpenID: null,
        UserInfo: null,
        DBInfo: [
            { DBKey: "BT_WDistricts01", WxSrc: "gh_0d7c003b3db1" },
            { DBKey: "BT_WDistricts01", WxSrc: "gh_0d7c003b3db1" },
            { DBKey: "BT_WDistricts", WxSrc: "gh_64c57bd19fef" },
            { DBKey: "BT_WDistricts", WxSrc: "gh_64c57bd19fef" },
        ],
        WxInfo: [
            {

            }
        ],

    },
    Tpls: {
        tplContent: { P: "Modules/Login/tplContent.htm", C: "" },
        tplQrcode: { P: "Modules/Login/tplQrcode.htm", C: "" },
    },
    Load: function () {
        var me = Login;
        try {
            Init.WebToast("配置信息加载中");
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = Login;
        try {
            Ac.acGetTable(Init.Path.Login_getWxInfo, {}, function (aRes) {
                me.Datas.WxInfo = aRes.Datas;
                if (me.Datas.WxInfo.length > 0) {
                    $("#webToast").remove();
                    var aHtml = bt(me.Tpls.tplContent.C, { tplData: me.Datas.WxInfo });
                    hhls.fillElement(".loginbody", aHtml);
                    $(".contact-box").each(function () {
                        animationHover(this, "pulse");
                    })
                }
            });
        }
        catch (e) {; }
    },
    QrConnect: function (aIndex) {
        var me = Login;
        var aInfo = me.Datas.WxInfo[aIndex];
        try {
            var aGuid = Math.random().toString();
            aGuid = aGuid.replaceAll("0", "").substring(2, 7);
            Ac.acCreateQrcode(aInfo.SrcID, aGuid, function (aRes) {
                var aTicket = aRes.Datas;
                var aUrl = Init.Datas.QR_SCENE_CreateUrl + aTicket;
                var aDlg = hhls.GetModalDlg("#dlgQrcode", me.Tpls.tplQrcode.C, function () {
                    $("#QrcodeCaption").text(aInfo.AppName);
                    var aImg = $(".WxImg");
                    try {
                        aImg.attr("src", aUrl);
                        var aPs = {
                            LogID: aGuid,
                            Ticket: aTicket,
                        }
                        me.Datas.t1 = setInterval("Login.doQrRefresh('" + aGuid + "', '" + aTicket + "')", 1000);
                        Ac.Info.DBKey = me.Datas.DBInfo[aIndex].DBKey;
                        Ac.Info.WxSrc = me.Datas.DBInfo[aIndex].WxSrc;

                        Init.Datas.SvrParas = "&Key=" + Ac.Info.DBKey + "&Src=" + Ac.Info.WxSrc;
                        Ac.acExecuteSql(Init.Path.Login_addDevLog, aPs, function (aRes) {
                            if (aRes.State == 1) {
                            } else {
                                alert("服务器故障");
                            }
                        });

                    }
                    catch (ee) {; }
                });
                aDlg.modal('show');
            })
        }
        catch (e) {
            var er = e;
        }
    },
    CheckUserInfo: function (aCallback) {
        var me = Login;
        try {
            if (me.Datas.OpenID != "") {
                Ac.acGetTable(Init.Path.Login_CheckAuth, { OpenID: me.Datas.OpenID }, function (aRes) {
                    me.Datas.UserInfo = null;
                    try {
                        if (aRes.Datas.length > 0) {
                            me.Datas.UserInfo = aRes.Datas[0];
                        }
                    }
                    catch (ee) {; }
                    hhls.callBack(aCallback, me.Datas.UserInfo);
                });
            }
            else {
                me.Datas.UserInfo = null;
                hhls.callBack(aCallback, me.Datas.UserInfo);
            }
        }
        catch (e) {; }
    },
    doQrRefresh: function (aLogID, aTicket) {
        var me = Login;
        try {
            var temp = $("#dlgQrcode").is(":hidden");//是否隐藏
            if (temp)
                clearInterval(me.Datas.t1);
            var aPs = {
                LogID: aLogID,
                Ticket: aTicket,
            }
            Ac.acGetTable(Init.Path.Login_getQrcodeState, aPs, function (aRes) {
                var aState = aRes.Datas[0].F_State;
                if (aState == 1) {
                    $("#scanFalse").css("display", "none");
                    $("#scanSuccess").css("display", "");
                } else if (aState == 2) { 
                    clearInterval(me.Datas.t1);
                    $("#txtScan").text("正在登录");
                    Init.WebToast("即将登录...");
                    var aOpenID = aRes.Datas[0].F_OpenID;

                    Ac.acGetTable(Init.Path.Login_CheckAuth, { OpenID: aOpenID }, function (aRes) {
                        me.Datas.UserInfo = null;
                        try {
                            if (aRes.Datas.length > 0) {
                                me.Datas.UserInfo = aRes.Datas[0]; 
                                Common.doSaveUserInfo(me.Datas.UserInfo);
                                var aUrl = "index.htm?" + Init.Datas.SvrParas;
                                hhls.goUrl(aUrl);
                            }
                        }
                        catch (ee) {; } 
                    });
                } else if (aState == 3) {
                    $("#scanSuccess").css("display", "none");
                    $("#scanFalse").css("display", "");
                } else if (aState == 4) {
                    $("#scanSuccess").css("display", "none");
                    $("#scanFalse").css("display", "");
                    $("#info").text("您还没有权限!");
                    clearInterval(me.Datas.t1);
                }
            });
        }
        catch (e) {; }
    },
    doLogin: function () {
        var me = Login;
        try {
            var aLogID = hhls.getUrlParam("LogID");
            var aPs = {
                LogID: aLogID,
                OpenID: Login.Datas.OpenID,
                State: 2
            }
            if (me.Datas.UserInfo != null) { 
                Init.WxToast("正在授权...");
                Ac.acExecuteSql(Init.Path.Login_updateDevLog, aPs, function (aRes) {
                    wx.closeWindow();
                });
            } else {
                Init.Wx_Toast("您还没有权限！", 1);
            }
        }
        catch (e) {; }
    },
    doCancel: function () {
        var me = Login;
        try {
            var aLogID = hhls.getUrlParam("LogID");
            var aPs = {
                LogID: aLogID,
                OpenID: Login.Datas.OpenID,
                State: 3
            }
            if (me.Datas.UserInfo != null) {
                Init.WxToast("正在取消...");
                Ac.acExecuteSql(Init.Path.Login_updateDevLog, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        wx.closeWindow();
                    } else {
                        $("#wxToast").remove();
                        alert("操作失败！");
                    }
                });
            } else {
                Init.Wx_Toast("您还没有权限！", 1);
            }
        }
        catch (e) {; }
    },
}