﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />
/// <reference path="../Chart/Chart.js" />


var Monitor = {
    Datas: {
        Statics: [
                    { F_Ind: 0, F_Code: "Current", F_Caption: "当前报单", F_Count: 0 },
                    { F_Ind: 1, F_Code: "Day", F_Caption: "今日报单", F_Count: 0 },
                    { F_Ind: 2, F_Code: "Week", F_Caption: "本周报单", F_Count: 0 },
                    { F_Ind: 3, F_Code: "Month", F_Caption: "本月报单", F_Count: 0 }
        ],
        subStatics: [
               {
                   F_ID: 0, F_Icon: "fa-pie-chart", F_Key: "pieChart", F_Caption: "报单分布_饼图", F_Btns: [
                      { F_Ind: 0, F_Key: 0, F_Caption: "全部" },
                      { F_Ind: 1, F_Key: 0, F_Caption: "当前" },
                      { F_Ind: 2, F_Key: 0, F_Caption: "今日" },
                      { F_Ind: 3, F_Key: 0, F_Caption: "本周" },
                      { F_Ind: 4, F_Key: 0, F_Caption: "本月" },
                      { F_Ind: 5, F_Key: 0, F_Caption: "月制" },
                   ]
               },
                {
                    F_ID: 1, F_Icon: "fa-bar-chart", F_Key: "barChart", F_Caption: "类型趋势_条形图", F_Btns: [
                    ]
                },
                {
                    F_ID: 2, F_Icon: "fa-line-chart", F_Key: "lineChart", F_Caption: "报单状态_折线图", F_Btns: [
                    ]
                },
        ],
        Dicts: [],
        myCharts: {
            Bar: null,
            Line: null,
            Pie: null,
        },
        Filters: {
            DifMonth: -1,
            DifDay: -1,
            DifYear: -1,
            State: -1, 
        },
    },
    Tpls: {
        tplPage: { P: "Modules/Monitor/tplPage.htm", C: "" },
        tplStatics: { P: "Modules/Monitor/tplStatics.htm", C: "" },
        tplPan: { P: "Modules/Monitor/tplPan.htm", C: "" }, 
    },
    Load: function () {
        var me = Monitor;
        try {
            doSetCurLeftMenu(5);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = Monitor;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);
            me.RefreshTable();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = Monitor;
        try {
            me.RefreshStatics();
            var aHtml = bt(me.Tpls.tplPan.C, { tplData: me.Datas.subStatics });
            hhls.fillElement("#divSubStatics", aHtml);
            me.RefreshPan();
        }
        catch (e) {
            var ee = e;
        }
    },
    RefreshStatics: function () {
        var me = Monitor;
        try {
            me.Datas.Statics = [
                    { F_Ind: 0, F_Code: "Current", F_Caption: "当前报单", F_Count: 0 },
                    { F_Ind: 1, F_Code: "Day", F_Caption: "今日报单", F_Count: 0 },
                    { F_Ind: 2, F_Code: "Week", F_Caption: "本周报单", F_Count: 0 },
                    { F_Ind: 3, F_Code: "Month", F_Caption: "本月报单", F_Count: 0 }
            ];
            Ac.acGetTable(Init.Path.Monitor_Statics, {}, function (aRes) {
                var aResult = aRes.Datas;
                $.each(aResult, function (aInd, aItem) {
                    me.Datas.Statics[aInd].F_Count = aItem.F_Count;
                });
                var aHtml = bt(me.Tpls.tplStatics.C, { tplData: me.Datas.Statics });
                hhls.fillElement("#divStatics", aHtml);
                window.setTimeout("Monitor.RefreshStatics()", 1000 * 60);
            });
        }
        catch (e) {; }
    },
    RefreshPan: function () {
        var me = Monitor;
        try {
            var aTables = {
                Dict: Init.Path.Charts_Dicts,
                Bar: Init.Path.Charts_Bar,
                Line: Init.Path.Charts_Line,
                Pie: Init.Path.Charts_Pie,
            }
            Ac.acGetDs(aTables, me.Datas.Filters, function (aRes) {
                me.Datas.Dicts = aRes.Datas.Dict;
                me.Datas.myCharts.Bar = aRes.Datas.Bar;
                me.Datas.myCharts.Line = aRes.Datas.Line;
                me.Datas.myCharts.Pie = aRes.Datas.Pie;
                me.RefreshPie("报单分布饼图_全部");
                me.RefreshLine();
                me.RefreshBar();
            });
        }
        catch (e) {; }
    },
    doPieSwitch: function (i, j) {
        var me = Monitor;
        try { 
            var aItem = $("." + i + " li");
            aItem.removeClass("active");
            $(aItem[j]).addClass("active");
            var aTitle = "报单分布饼图_";
            var aInfo = me.Datas.subStatics[i].F_Btns[j];
            if (aInfo.F_Ind == 0) {
                me.Datas.Filters = {
                    DifMonth: -1,
                    DifDay: -1,
                    DifYear: -1,
                    State: -1,
                };
                aTitle += "全部";
            } else if (aInfo.F_Ind == 1) {
                me.Datas.Filters = {
                    DifMonth: -1,
                    DifDay: -1,
                    DifYear: -1,
                    State: 0,
                };
                aTitle += "当前";
            } else if (aInfo.F_Ind == 2) {
                me.Datas.Filters = {
                    DifMonth: -1,
                    DifDay: 0,
                    DifYear: -1,
                    State: -1,
                };
                aTitle += "本日";
            } else if (aInfo.F_Ind == 3) {
                me.Datas.Filters = {
                    DifMonth: -1,
                    DifDay: 6,
                    DifYear: -1,
                    State: -1,
                };
                aTitle += "本周";
            } else if (aInfo.F_Ind == 4) {
                me.Datas.Filters = {
                    DifMonth: 0,
                    DifDay: -1,
                    DifYear: -1,
                    State: -1,
                };
                aTitle += "本月";
            } else if (aInfo.F_Ind == 5) {
                me.Datas.Filters = {
                    DifMonth: -1,
                    DifDay: -1,
                    DifYear: -1,
                    State: -1,
                };
                var aMon = parseInt(Math.random() * 12);
                me.Datas.Filters.DifMonth = aMon;
                aTitle += aMon != 0 ? aMon + "月内" : "本月内";
            }
            Ac.acGetTable(Init.Path.Charts_Pie, me.Datas.Filters, function (aRes) { 
                me.Datas.myCharts.Pie = aRes.Datas;
                me.RefreshPie(aTitle);
            })
        }
        catch (e) {; }
    },
    RefreshBar: function () {
        var me = Monitor;
        try {
            var aOption = Charts.tplCharts.tplBar;
            aOption.xAxis[0].data = [];
            for (var i in me.Datas.Dicts) {
                var aItem = me.Datas.Dicts[i];
                aOption.xAxis[0].data.push(aItem.F_Caption);
                for (var j in me.Datas.myCharts.Bar) {
                    var aSubBar = me.Datas.myCharts.Bar[j];
                    if (aSubBar.F_Chk == 0 && aSubBar.F_DictCode == aItem.F_Code) {
                        aOption.series[0].data[i] = aSubBar.F_Count;
                        aSubBar.F_Chk = 1;
                        break;
                    }
                }
            }
            $(".divItem .barChart").css("height", "300px");
            var aCharts = echarts.init($(".divItem .barChart")[0], 'macarons');
            aCharts.setOption(aOption);
            setTimeout(function () {
                window.onresize = function () {
                    aCharts.resize();
                }
            }, 200);
        }
        catch (e) {; }
    },
    RefreshLine: function () {
        var me = Monitor;
        try {
            var aOption = Charts.tplCharts.tplLine;
            aOption.xAxis[0].data = [];
            aOption.legend.data = [];

            var myDate = new Date();
            var year = myDate.getFullYear();
            var month = myDate.getMonth() + 1;

            if (month >= 7) {
                for (var j = month - 6; j <= month; j++) {
                    aOption.xAxis[0].data.push(year + "年" + j + "月");
                }
            }
            else {
                for (var i = 6 + month; i <= 12; i++) {
                    aOption.xAxis[0].data.push(year - 1 + "年" + i + "月");
                }
                for (var i = 1; i <= month; i++) {
                    aOption.xAxis[0].data.push(year + "年" + i + "月");
                }
            }
            var series = [];
            for (i in me.Datas.Dicts) {
                var aItem = me.Datas.Dicts[i];
                aOption.legend.data.push(aItem.F_Caption);
                var aInfo = {
                    name: '',
                    type: 'line',
                    smooth: true,
                    itemStyle: { normal: { areaStyle: { type: 'default' } } },
                    data: [0, 0, 0, 0, 0, 0, 0]
                };
                aInfo.name = me.Datas.Dicts[i].F_Caption;
                $.each(me.Datas.myCharts.Line, function (aInd, aSubLine) {
                    if (aSubLine.F_Chk == 0 && aSubLine.F_DictCode == aItem.F_Code) {
                        aInfo.data[aSubLine.F_Ind] = aSubLine.F_Count;
                        aSubLine.F_Chk = 1;
                    }
                });
                series.push(aInfo);
            }
            aOption.series = series;
            $(".divItem .lineChart").css("height", "300px");
            var aCharts = echarts.init($(".divItem .lineChart")[0], 'macarons');
            aCharts.setOption(aOption);
            setTimeout(function () {
                window.onresize = function () {
                    aCharts.resize();
                }
            }, 200);
        }
        catch (e) {; }
    },
    RefreshPie: function (aTitle) {
        var me = Monitor;
        try { 
            var aOption = Charts.tplCharts.tplPie;
            aOption.legend.data = [];
            aOption.title.text = aTitle;
            for (i in me.Datas.Dicts) {
                var aItem = me.Datas.Dicts[i];
                aOption.legend.data.push(aItem.F_Caption);
                var flag = false; 
                for(j in me.Datas.myCharts.Pie){
                    if (me.Datas.myCharts.Pie[j].name == aItem.F_Caption) {
                        flag = true;
                        break;
                    }
                }
                if(!flag){ 
                    var aInfo = { value: 0, name: aItem.F_Caption };
                    me.Datas.myCharts.Pie.push(aInfo);
                }
            } 
            aOption.series[0].data = me.Datas.myCharts.Pie;
            
            $(".divItem .pieChart").css("height", "300px");
            var aCharts = echarts.init($(".divItem .pieChart")[0], 'macarons');
            aCharts.setOption(aOption);
            setTimeout(function () {
                window.onresize = function () {
                    aCharts.resize();
                }
            }, 200);
        }
        catch (e) {; }
    },
    doSearch: function () {
        var me = Monitor;
        try {
            var txtSearch = $("#txtCondition").val();
            if (txtSearch != '' && (txtSearch.indexOf("饼图") >= 0 || txtSearch.indexOf("条形图") >= 0 || txtSearch.indexOf("折线图") >= 0)) {
                var split = txtSearch.split("|")
                if (split.length > 0) {
                    $("#divSubStatics .col-lg-6").css("display", "none");
                    for (var s in split) {
                        if (split[s] == "饼图") {
                            $("#divSubStatics .pieChart").css("display", "");
                        }
                        if (split[s] == "条形图") {
                            $("#divSubStatics .barChart").css("display", "");
                        }
                        if (split[s] == "折线图") {
                            $("#divSubStatics .lineChart").css("display", "");
                        }
                    }
                }
            } else if (txtSearch == '') {
                $("#divSubStatics .col-lg-6").css("display", "");
            } else {
                alert("搜索不符合要求");
            }
        }
        catch (e) {; }
    },

};
