﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />
/// <reference path="../../../../../../applibs/sdk/hhwxMsg.js" />

var Notice = { 
    Datas: {
        Levels: {
            Index: '0',
            Items: []
        },
        PostID:0,
        Notices: [],
        UserRoles: [],
    }, 
    Tpls: {
        tplPage: { P: "Modules/Notice/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/Notice/tplTableItem.htm", C: "" },
        tplNotice: { P: "Modules/Notice/tplNotice.htm", C: "" }
    },
    Load: function () {
        var me = Notice;
        try {
            doSetCurLeftMenu(6);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) { ; }
    },
    Refresh: function () {
        var me = Notice;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);
            $("#tBodyTr").html(Init.Utility.Loading);
            me.RefreshTable();
        }
        catch (e) { ; }
    }, 
    RefreshTable: function () {
        var me = Notice;
        try {  
            var aTables = {
                Notices: Init.Path.Notice_Notices,
                Roles: Init.Path.Notice_Roles,
            };
            var aPs = { 
                Code: me.Datas.Levels.Index
            };
            Ac.acGetDs(aTables, aPs, function (aRes) {
                me.Datas.Notices = aRes.Datas.Notices;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Notices });
                hhls.fillElement("#tBodyUsers", aHtml);
                me.Datas.UserRoles = aRes.Datas.Roles;
                me.Datas.UserRoles.splice(0, 0, { F_Code: "0", F_Caption: "所有用户" });
                me.RefreshRole(me.Datas.UserRoles, "#cmbRoles"); 
            });
        }
        catch (e) { ; }
    }, 
    RefreshRole: function (aInfo, aElement) {
        var me = Notice;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_Code + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (cer) {; }
    },
    OnPickRoles: function () {
        var me = Notice;
        try {
            me.Datas.Levels.Index = $("#cmbRoles").val();
            var aPs = { 
                Code: me.Datas.Levels.Index
            };
            Ac.acGetTable(Init.Path.Notice_Notices, aPs, function (aRes) {
                me.Datas.Notices = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Notices });
                hhls.fillElement("#tBodyUsers", aHtml);
            });
        }
        catch (e) {; }
    }, 
    doShowDlg: function (aIndex) {
        var me = Notice;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Notices[aIndex].F_ID;
            var aID = "dlgNoticeManage";
            var onShow = function (e) {
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Notices[aIndex];
                    $("#txtTitle").val(aInfo.F_Title);
                    $("#txtLabTitle").val(aInfo.F_LabTitle);
                    $("#txtAddress").val(aInfo.F_Address);
                    $("#txtDesc").val(aInfo.F_Desc);
                    me.RefreshRole(me.Datas.UserRoles, "#cmbRole");
                    $("#cmbRole").val(aInfo.F_CurCode);
                } else {
                    me.RefreshRole(me.Datas.UserRoles, "#cmbRole");
                }
            };
            var onHide = function (e) { 
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = Notice;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.Notice_New : Init.Path.Notice_Edit;
            var aPs = {
                Title: $("#txtTitle").val(),
                LabTitle: $("#txtLabTitle").val(), 
                Address: $("#txtAddress").val(),
                Desc: $("#txtDesc").val(),
                Code: $("#cmbRole").val(),
                ID: me.Datas.PostID,
                HashID: hhls.getGuid(),
                UserID: Common.Datas.UserInfo.F_ID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgNoticeManage").modal("toggle");
                    //Send Msg
                    me.doSendMsg(aPs);
                }
                else {
                    alert("提交失败！");
                }
            });
        }
        catch (e) {; }
    },
    doSendMsg: function (aInfo) {
        var me = Notice;
        try {
            var aWxMsg = {};

            var aUrl = Init.Datas.MsgUrl + '{pgView}.htm?OpenID={OpenID}&HashID=' + aInfo.HashID + Init.Datas.SvrParas + '&Tm=' + Math.random();

            var article = {
                title: "Happy Day",
                description: "Is Really A Happy Day",
                url: "URL",
                picurl: "PIC_URL"
            };
            article.title = aInfo.Title;
            article.description = "<<" + aInfo.LabTitle + ">> \n" + aInfo.Desc;
            article.url = aUrl;
            article.picurl = Init.Datas.RootPath + "/upload/notice.png";

            aWxMsg = WxMsgTpl.news;
            aWxMsg.news.articles.push(article);
            var aPath = aInfo.Code == '0' ? Init.Path.Notice_OpenIDLists : Init.Path.Notice_OpenIDList;
            Ac.acWxSendMsg(aWxMsg, aPath, { DictCate: "NoticeCate", Cate: aInfo.Code }, function (aRes) {
                if (aRes.State == 1) {
                    Init.Web_Toast("该消息已经被指定对象接收", 1); 
                } else {
                    Init.Web_Toast("该消息未被接收，请重新提交", 1);
                    //此时应该删除之前所提交的内容（这里不讨论）
                }
            })
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = Notice;
        try {
            var aFlag = window.confirm("是否确定要删除该公告？");
            if (aFlag) {
                var aPs = { ID: me.Datas.Notices[aIndex].F_ID };
                Ac.acExecuteSql(Init.Path.Notice_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        //me.RefreshTable();
                        $(".tr" + aIndex).css("display", "none");
                    }
                    else {
                        alert("删除失败！");
                    }
                });
            }
        }
        catch (e) {; }
    }
};
