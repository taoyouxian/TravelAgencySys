﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var OperatorManage = { 
    Datas: {
        Levels: {
            Index: 0,
            Items: []
        },
        PostID: 0, 
        Operators: [],
        OperatorRoles: []
    }, 
    Tpls: {
        tplPage: { P: "Modules/OperatorManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/OperatorManage/tplTableItem.htm", C: "" },
        tplRoleAuth: { P: "Modules/OperatorManage/tplRoleAuth.htm", C: "" }
    },
    Load: function () {
        var me = OperatorManage;
        try {
            doSetCurLeftMenu(2);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) { ; }
    },
    Refresh: function () {
        var me = OperatorManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);
            $("#tBodyTr").html(Init.Utility.Loading);
            me.RefreshTable();
        }
        catch (e) { ; }
    },
    RefreshTable: function () {
        var me = OperatorManage;
        try {
            var aTables = {
                Operators: Init.Path.OperatorManage_Operators,
                Roles: Init.Path.OperatorManage_Roles,
            };
            var aPs = { RoleID: me.Datas.Levels.Index };
            Ac.acGetDs(aTables, aPs, function (aRes) {
                me.Datas.Operators = aRes.Datas.Operators;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Operators });
                hhls.fillElement("#tBodyOperators", aHtml);
                me.Datas.OperatorRoles = aRes.Datas.Roles; 
                me.Datas.OperatorRoles.splice(0, 0, { F_ID: "0", F_Caption: "所有操作员" });
                me.RefreshRole(me.Datas.OperatorRoles, "#cmbRoles");
                //var aInfo = [{ F_ID: 0, F_Caption: "所有操作员" }];
                //$.merge(aInfo, me.Datas.OperatorRoles);
                //me.RefreshRole(aInfo, "#cmbRoles");
            });
        }
        catch (e) { ; }
    }, 
    RefreshRole: function (aInfo, aElement) {
        var me = OperatorManage;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_ID + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (cer) {; }
    },
    OnPickRoles: function () {
        var me = OperatorManage;
        try {
            me.Datas.Levels.Index = $("#cmbRoles").val();
            var aPs = { RoleID: me.Datas.Levels.Index }; 
            Ac.acGetTable(Init.Path.OperatorManage_Operators, aPs, function (aRes) {
                me.Datas.Operators = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Operators });
                hhls.fillElement("#tBodyOperators", aHtml);
            });
        }
        catch (e) { ; }
    },
    doSetRoleAuth: function (aIndex) {
        var me = OperatorManage;
        try {
            var aInfo = { UserID: me.Datas.Operators[aIndex].F_ID };
            Init.Web_Toast("功能待开发", 1);
        }
        catch (e) {; }
    },
    doSetPwd: function (aIndex) {
        var me = OperatorManage;
        try {
            var aPs = { ID: me.Datas.Operators[aIndex].F_ID }; 
            Common.doUserAction("UserManage_setPwd", aPs, function (aRes) {
                if (aRes.State == 1) { } else {
                    alert("重置失败！");
                }
            })
        }
        catch (e) {; }
    },
    doShowDlg: function (aIndex) {
        var me = OperatorManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Operators[aIndex].F_ID;
            var aID = "dlgOperatorManage";
            var onShow = function (e) {
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Operators[aIndex];
                    $("#txtCode").val(aInfo.F_Code);
                    $("#txtCaption").val(aInfo.F_Caption);
                    $("#txtTel").val(aInfo.F_Tel);
                    $("#txtMail").val(aInfo.F_Mail);
                    $("#txtDesc").val(aInfo.F_Desc);
                    me.RefreshRole(me.Datas.OperatorRoles, "#cmbRole");
                    $("#cmbRole").val(aInfo.F_RoleID);
                } else {
                    me.RefreshRole(me.Datas.OperatorRoles, "#cmbRole"); 
                }
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) { ; }
    },
    doPost: function () {
        var me = OperatorManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.OperatorManage_New : Init.Path.OperatorManage_Edit;
            var aPs = {
                Code: $("#txtCode").val(),
                Caption: $("#txtCaption").val(),
                Tel: $("#txtTel").val(),
                Mail: $("#txtMail").val(),
                Desc: $("#txtDesc").val(),
                RoleID: $("#cmbRole").val(),
                ID: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgOperatorManage").modal("toggle");
                }
                else {
                    alert("提交失败！");
                }
            });
        }
        catch (e) { ; }
    },
    doDelete: function (aIndex) {
        var me = OperatorManage; 
        try {
            var aFlag = window.confirm("是否确定要删除该用户账号？");
            if (aFlag) {
                var aPs = { ID: me.Datas.Operators[aIndex].F_ID };
                Ac.acExecuteSql(Init.Path.OperatorManage_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        //me.RefreshTable();
                        $(".tr" + aIndex).css("display", "none");
                    }
                    else {
                        alert("删除失败！");
                    }
                });
            }
        }
        catch (e) { ; }
    }
};
