﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />



var RoleManage = { 
    Datas: { 
        PostID: 0, 
        Roles: []
    }, 
    Tpls: {
        tplPage: { P: "Modules/RoleManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/RoleManage/tplTableItem.htm", C: "" }
    },
    Load: function () {
        var me = RoleManage;
        try {
            doSetCurLeftMenu(1);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = RoleManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);
            $("#tBodyTr").html(Init.Utility.Loading);
            me.RefreshTable();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = RoleManage;
        try {  
            Ac.acGetTable(Init.Path.RoleManage_Roles, {}, function (aRes) {
                me.Datas.Roles = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Roles });
                hhls.fillElement("#tBodyRoles", aHtml);
            });
        }
        catch (e) {; }
    }, 
    doSetRoleAuth: function (aIndex) {
        var me = RoleManage;
        try {
            Init.Web_Toast("该功能待测试", 1);
        }
        catch (e) {; }
    },
    doShowDlg: function (aIndex) {
        var me = RoleManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Roles[aIndex].F_ID;
            var aID = "dlgRoleManage";
            var onShow = function (e) {
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Roles[aIndex];
                    $("#txtCode").val(aInfo.F_Code);
                    $("#txtCaption").val(aInfo.F_Caption);
                    $("#txtDesc").val(aInfo.F_Desc);
                    $("#cmbLevel").val(aInfo.F_Level);
                }
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) {; }
    },
    doPost: function () {
        var me = RoleManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.RoleManage_New : Init.Path.RoleManage_Edit;
            var aPs = {
                Code: $("#txtCode").val(),
                Caption: $("#txtCaption").val(),
                Desc: $("#txtDesc").val(),
                Level: $("#cmbLevel").val(),
                ID: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgRoleManage").modal("toggle");
                }
                else {
                    alert("提交失败！");
                }
            });
        }
        catch (e) {; }
    },
    doDelete: function (aIndex) {
        var me = RoleManage;
        try {
            var aFlag = window.confirm("是否确定要删除该角色分类？");
            if (aFlag) {
                var aPs = { ID: me.Datas.Roles[aIndex].F_ID };
                Ac.acExecuteSql(Init.Path.RoleManage_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        me.RefreshTable();
                    }
                    else {
                        alert("删除失败！");
                    }
                });
            }
        }
        catch (e) {; }
    }
};
