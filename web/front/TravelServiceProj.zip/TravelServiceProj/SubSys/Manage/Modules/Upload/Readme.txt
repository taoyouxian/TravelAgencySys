﻿

Upload - 副本.js
	1、对于doFold() 展开分类
	2、分类的排版

Problems: Record only has one type, not RentHouse with many conditions