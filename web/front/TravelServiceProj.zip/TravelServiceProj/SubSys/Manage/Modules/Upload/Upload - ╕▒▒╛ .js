﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var Upload = {
    UrlPs: {},
    Datas: { 
        Dicts: [],
        States: {
            Index: 1,
            Items: [
                { F_ID: 9, F_Caption: "所有状态" },
                { F_ID: 2, F_Caption: "故障" },
                { F_ID: 1, F_Caption: "正常" },
                { F_ID: 0, F_Caption: "未开通" },
            ]
        },
        Devs: []
    }, 
    Tpls: {
        tplPage: { P: "Modules/Upload/tplPage.htm", C: "" }, 
        tplTableItem: { P: "Modules/Upload/tplTableItem.htm", C: "" }, 
        tplType: { P: "Modules/Upload/tplType.htm", C: "" }, 
        tplPageFooter: { P: "Modules/Upload/tplPageFooter.htm", C: "" }
    },
    Load: function () {
        var me = Upload;
        try {
            doSetCurLeftMenu(4);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) { ; }
    },
    Refresh: function () {
        var me = Upload;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);

            $('.txtDt').datetimepicker({
                language: 'zh-CN',
                minView: "month", //选择日期后，不会再跳转去选择时分秒 
                format: "yyyy-mm-dd",
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: 1
            }).on('changeDate', function (ev) {
                $(this).datetimepicker('hide');
            });

            $("#dtpFrom").val((new Date().addDays(-6)).toString("yyyy-MM-dd")).datetimepicker("update");
            $("#dtpTo").val((new Date().addDays(1)).toString("yyyy-MM-dd")).datetimepicker("update");

            hhls.assignSelect("#cmbState", me.Datas.States.Items, "F_ID", "F_Caption");
            $("#cmbState").val("2");
            //me.RefreshParentDicts();
        }
        catch (e) { ; }
    },
    RefreshTable: function () {
        var me = Upload;
        try { 
            var aPs = {
                OrgParentID: $("#cmbParentOrg").val(),
                OrgID: $("#cmbOrg").val(),
                State: $("#cmbState").val()
            };
            Ac.acGetTable(me.Paths.Devs, aPs, function (aRes) {
                me.Datas.Devs = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Devs });
                hhls.fillElement("#tBodyDicts", aHtml);
            });
        }
        catch (e) { ; }
    }, 
    RefreshParentDicts: function () {
        var me = Upload;
        try {
            Ac.acGetTable(me.Paths.Dicts, {}, function (aRes) {
                me.Datas.Dicts = aRes.Datas;
                var aParentDicts = $.grep(me.Datas.Dicts, function (aItem) {
                    var aFlag = aItem.F_ParentID == 0 || aItem.F_ParentID == null;
                    return aFlag;
                });
                aParentDicts.splice(0, 0, { F_ID: "0", F_Caption: "全部" });
                hhls.assignSelect("#cmbParentOrg", aParentDicts, "F_ID", "F_Caption");
                me.RefreshDicts();
            });
        }
        catch (e) { ; }
    },
    RefreshDicts: function () {
        var me = Upload;
        try {
            var aPid = $("#cmbParentOrg").val();
            var aAll = [{ F_ID: "0", F_Caption: "全部"}];
            var aDicts = aAll;
            if (aPid > 0) {
                aDicts = $.grep(me.Datas.Dicts, function (aItem) {
                    var aFlag = aItem.F_ParentID == aPid;
                    return aFlag;
                });
                aDicts.splice(0, 0, { F_ID: "0", F_Caption: "全部" });
                hhls.assignSelect("#cmbOrg", aDicts, "F_ID", "F_Caption");
            }
            else {
                hhls.assignSelect("#cmbOrg", aDicts, "F_ID", "F_Caption");
            }
            me.RefreshTable();
        }
        catch (e) { ; }
    },
    RefreshStates: function () {
        var me = Upload;
        try {
            var aPid = $("#cmbParentOrg").val();
            var aAll = [{ F_ID: "0", F_Caption: "全部"}];
            var aDicts = aAll;
            if (aPid > 0) {
                aDicts = $.grep(me.Datas.Dicts, function (aItem) {
                    var aFlag = aItem.F_ParentID == aPid;
                    return aFlag;
                });
                aDicts.splice(0, 0, { F_ID: "0", F_Caption: "全部" });
                hhls.assignSelect("#cmbOrg", aDicts, "F_ID", "F_Caption");
            }
            else {
                hhls.assignSelect("#cmbOrg", aDicts, "F_ID", "F_Caption");
            }
        }
        catch (e) { ; }
    },
    doFold: function (aIndex) {
        var me = Upload;
        try {
            if (aIndex == 0) {
                $(".divCeng .divFilter").css("display", "none");
                $(".divCeng .none").css("display", "");
                if(me.Datas.Dicts.length == 0)
                Ac.acGetTable(Init.Path.Upload_Dicts, {}, function (aRes) {
                    var i = 0;
                    var aDicts = $.grep(aRes.Datas, function (aItem, aIndex) {
                        var aFlag = aItem.F_Level == 1;
                        if (aFlag) {
                            aItem.SubDicts = $.grep(aRes.Datas, function (aSubItem) {
                                var aSubFlag = aSubItem.F_ParentID == aItem.F_ID;
                                return aSubFlag;
                            }); 
                            aItem.DictIndex = i;
                            i++;
                            aItem.SubDicts.splice(0, 0, { F_ID: "0", F_Caption: "不限" });
                        }
                        return aFlag; 
                    }); 
                    me.Datas.Dicts = aDicts;
                    var aHtml = bt(me.Tpls.tplType.C, { tplData: me.Datas.Dicts });
                    hhls.fillElement(".divTypes", aHtml);

                });
            } else { 
                $(".divCeng .none").css("display", "none");
                $(".divCeng .divFilter").css("display", "");
            }
        }
        catch (e) { ; }
    },
    OnPickParentOrg: function () {
        var me = Upload;
        try {
            me.RefreshDicts();
        }
        catch (e) { ; }
    },
    OnPickOrg: function () {
        var me = Upload;
        try {
            me.RefreshTable();
        }
        catch (e) { ; }
    },
    OnPickState: function () {
        var me = Upload;
        try {
            me.RefreshTable();
        }
        catch (e) { ; }
    }
};
