﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var Upload = {
    Datas: {
        Dicts: [],
        States: {
            Index: 1,
            Items: [ 
            ]
        },
        CurIndex: 1,
        Records: {
            OrderFields: "F_ID desc",
            PageSize: 9,
            PageIndex: 1,
            PageCount: [],
            RowCount: [],
            DataList: []
        },
        Filters: {
            BeginTm: 0,
            EndTm: 0,
            State: 7,
            DictID: 0,
            Keyword: '',
            UserCaption: '',
            WorkerCaption: '',
            Address: '',
        }
    },
    Tpls: {
        tplPage: { P: "Modules/Upload/tplPage.htm", C: "" },
        tplList: { P: "Modules/Upload/tplList.htm", C: "" },
        tplBox: { P: "Modules/Upload/tplBox.htm", C: "" },
        tplPageFooter: { P: "Modules/Upload/tplPageFooter.htm", C: "" }
    },
    Load: function () {
        var me = Upload;
        try {
            doSetCurLeftMenu(4);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) {; }
    },
    Refresh: function () {
        var me = Upload;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml); 

            $(".RecordList").html(Init.Utility.Loading);

            $('.txtDt').datetimepicker({
                language: 'zh-CN',
                minView: "month", //选择日期后，不会再跳转去选择时分秒 
                format: "yyyy-mm-dd",
                weekStart: 1,
                todayBtn: 1,
                autoclose: 1,
                todayHighlight: 1,
                startView: 2,
                forceParse: 0,
                showMeridian: 1
            }).on('changeDate', function (ev) {
                $(this).datetimepicker('hide');
            });

            $("#dtpFrom").val((new Date().addDays(-6)).toString("yyyy-MM-dd")).datetimepicker("update");
            $("#dtpTo").val((new Date().addDays(1)).toString("yyyy-MM-dd")).datetimepicker("update");

            hhls.assignSelect("#cmbState", me.Datas.States.Items, "F_ID", "F_Caption");
            $("#cmbState").val("2");
            me.RefreshParentDicts();
        }
        catch (e) {; }
    },
    RefreshTable: function () {
        var me = Upload;
        try {
            var aShow = false;
            if (me.Datas.Filters.BeginTm != $("#dtpFrom").val()) {
                aShow = true;
                me.Datas.Filters.BeginTm = $("#dtpFrom").val();
            }
            if (me.Datas.Filters.EndTm != $("#dtpTo").val()) {
                aShow = true;
                me.Datas.Filters.EndTm = $("#dtpTo").val();
            }
            if (aShow) {
                $(".RecordList").html(Init.Utility.Loading);
                $(".divPagingOutter").empty();
            }
            me.Datas.Filters.DictID = $("#cmbParentDict").val();
            var aKeyword = $("#cmbDict").val();
            me.Datas.Filters.Keyword = aKeyword == "全部" ? "" : aKeyword;
            Ac.acGetPageTable(Init.Path.Upload_Records, me.Datas.Records.OrderFields, me.Datas.Records.PageSize, me.Datas.Records.PageIndex, me.Datas.Filters, function (aRes) {
                $("#webToast").remove();
                me.Datas.Records = aRes.Datas;
                var aHtml = null;
                $(".RecordList").empty();
                if (me.Datas.CurIndex == 1) {
                    if (me.Datas.Records.DataList.length > 0) {
                        aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Records });
                        hhls.fillElement(".RecordList", aHtml);
                    }
                } else {
                    if (me.Datas.Records.DataList.length > 0) {
                        aHtml = bt(me.Tpls.tplBox.C, { tplData: me.Datas.Records });
                        hhls.fillElement(".RecordList", aHtml);
                    }
                }
                Init.LoadWxImg();
                aHtml = bt(me.Tpls.tplPageFooter.C, { tplData: me.Datas.Records });
                hhls.fillElement(".divPagingOutter", aHtml);
            });
        }
        catch (e) {; }
    },
    onGetDetail: function (aIndex) {
        var me = Upload;
        try { 
            var aRecord = me.Datas.Records.DataList[aIndex];
            var aUrl = "detail.htm?" +Init.Datas.SvrParas + "&hashed_id=" + aRecord.hashed_id;
            window.open(aUrl);
        }
        catch (e) {; }
    },
    RefreshParentDicts: function () {
        var me = Upload;
        try {
            Ac.acGetTable(Init.Path.Upload_Dicts, {}, function (aRes) {
                me.Datas.Dicts = aRes.Datas;
                var aParentDicts = $.grep(me.Datas.Dicts, function (aItem) {
                    var aFlag = aItem.F_ParentID == 0 || aItem.F_ParentID == null;
                    return aFlag;
                });
                aParentDicts.splice(0, 0, { F_ID: "0", F_Caption: "全部" });
                hhls.assignSelect("#cmbParentDict", aParentDicts, "F_ID", "F_Caption");
                me.RefreshDicts();
            });
        }
        catch (e) {; }
    },
    RefreshDicts: function () {
        var me = Upload;
        try {
            var aPid = $("#cmbParentDict").val();
            var aAll = [{ F_ID: "0", F_Caption: "全部" }];
            var aDicts = aAll;
            if (aPid > 0) {
                aDicts = $.grep(me.Datas.Dicts, function (aItem) {
                    var aFlag = aItem.F_ParentID == aPid;
                    return aFlag;
                });
                aDicts.splice(0, 0, { F_ID: "0", F_Caption: "全部" });
                hhls.assignSelect("#cmbDict", aDicts, "F_Caption", "F_Caption");
            }
            else {
                hhls.assignSelect("#cmbDict", aDicts, "F_Caption", "F_Caption");
            }
            me.RefreshTable();
        }
        catch (e) {; }
    },
    OnPickParentDict: function () {
        var me = Upload;
        try {
            Init.WebToast("数据加载中");
            me.RefreshDicts();
        }
        catch (e) {; }
    },
    OnPickDict: function () {
        var me = Upload;
        try {
            Init.WebToast("数据加载中");
            me.RefreshTable();
        }
        catch (e) {; }
    },
    doOnPickUploadState: function (aIndex) {
        var me = Upload;
        try {
            if (me.Datas.Filters.State != aIndex) { 
                var aItems = $(".divPickItems ul li");
                aItems.removeClass("active");
                $(aItems[aIndex]).addClass("active");
                Init.WebToast("数据加载中");
                me.Datas.Filters.State = aIndex;
                me.RefreshTable();
            }
        }
        catch (e) {; }
    },
    getFilters: function () {
        var me = Upload;
        try {
            var txtSearch = $("#txtFilters").val();
            if (txtSearch != '') {
                var split = txtSearch.split("|")
                if (split.length > 0) {
                    Init.WebToast("数据加载中");
                    me.Datas.Filters.UserCaption = split[0] != null ? split[0] : '';
                    me.Datas.Filters.WorkerCaption = split[1] != null ? split[1] : '';
                    me.Datas.Filters.Address = split[2] != null ? split[2] : '';
                    me.RefreshTable();
                }
            }   else {
                alert("搜索不符合要求");
            }  
        }
        catch (e) {; }
    },
    doListTable: function (aIndex) {
        var me = Upload;
        try {
            var aItem = $("ul.lstPickItem li");
            aItem.removeClass("active");
            $(aItem[aIndex]).addClass("active");
            if (me.Datas.CurIndex != aIndex) {
                me.Datas.CurIndex = aIndex;
                var aHtml = null;
                if (me.Datas.CurIndex == 1) {
                    if (me.Datas.Records.DataList.length > 0) {
                        aHtml = bt(me.Tpls.tplList.C, { tplData: me.Datas.Records });
                        hhls.fillElement(".RecordList", aHtml);
                    }
                } else {
                    if (me.Datas.Records.DataList.length > 0) {
                        aHtml = bt(me.Tpls.tplBox.C, { tplData: me.Datas.Records });
                        hhls.fillElement(".RecordList", aHtml);
                    }
                }
            }
        }
        catch (e) {; }
    },
    ChangePage: function (aAction) {
        var me = Upload;
        try {
            var flag = false;
            Init.WebToast();
            if (aAction == 0) {
                me.Datas.Records.PageSize = parseInt($(".cmbPageSize").val());
            }
            else if (aAction == 1) {
                if (me.Datas.Records.PageIndex > 1) {
                    $(".web-toast_content").text("首页数据加载中");
                    me.Datas.Records.PageIndex = 1;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是首页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 2) {
                if (me.Datas.Records.PageIndex > 1) {
                    $(".web-toast_content").text("上一页数据加载中");
                    me.Datas.Records.PageIndex--;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是第一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 3) {
                if (me.Datas.Records.PageIndex < me.Datas.Records.PageCount) {
                    $(".web-toast_content").text("下一页数据加载中");
                    me.Datas.Records.PageIndex++;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是最后一页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 4) {
                if (me.Datas.Records.PageIndex < me.Datas.Records.PageCount) {
                    $(".web-toast_content").text("末页数据加载中");
                    me.Datas.Records.PageIndex = me.Datas.Records.PageCount;
                }
                else {
                    flag = true;
                    $(".web-toast_content").text("当前已经是末页");
                    Init.ClearToast("#webToast", 1)
                }
            }
            else if (aAction == 5) {
                var aPageNum = $(".txtPageNum").val();
                if (me.Datas.Records.PageIndex < aPageNum && aPageNum < me.Datas.Records.PageCount)
                    me.Datas.Records.PageIndex = aPageNum;
                else {
                    flag = true;
                    $(".web-toast_content").text("请输入符合的页码");
                    Init.ClearToast("#webToast", 1)
                }
            }
            if (!flag)
                me.RefreshTable();
        }
        catch (E) {; }
    },
};
