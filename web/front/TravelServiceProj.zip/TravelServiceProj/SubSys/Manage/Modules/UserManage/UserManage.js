﻿/// <reference path="../../../../../../applibs/sdk/jQuery-2.1.3.min.js" />
/// <reference path="../../../../../../applibs/sdk/json.js" />
/// <reference path="../../../../../../applibs/sdk/date.js" />
/// <reference path="../../../../../../applibs/sdk/baiduTpls.js" />
/// <reference path="../../../../../../applibs/sdk/base64.js" />
/// <reference path="../../../../../../applibs/sdk/hhls.js" />
/// <reference path="../../../../../../applibs/sdk/hhac.js" />
/// <reference path="../../../../../../applibs/sdk/hhls_wxConfirm.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/js/bootstrap.min.js" />
/// <reference path="../../../../../../applibs/bootstrap-3.3.5-dist/datetimepicker/js/bootstrap-datetimepicker.js" />
/// <reference path="../../../../Commons/Common.js" />

var UserManage = { 
    Datas: {
        Levels: {
            Index: 0,
            Items: []
        },
        PostID: 0, 
        Users: [],
        UserRoles: []
    }, 
    Tpls: {
        tplPage: { P: "Modules/UserManage/tplPage.htm", C: "" },
        tplTableItem: { P: "Modules/UserManage/tplTableItem.htm", C: "" },
        tplDictAuth: { P: "Modules/UserManage/tplDictAuth.htm", C: "" }
    },
    Load: function () {
        var me = UserManage;
        try {
            doSetCurLeftMenu(3);
            hhls.GetTpls(me.Tpls, function () {
                me.Refresh();
            });
        }
        catch (e) { ; }
    },
    Refresh: function () {
        var me = UserManage;
        try {
            var aHtml = me.Tpls.tplPage.C;
            hhls.fillElement("#divModulePage", aHtml);
            $("#tBodyTr").html(Init.Utility.Loading);
            me.RefreshTable();
        }
        catch (e) { ; }
    },
    RefreshTable: function () {
        var me = UserManage;
        try {
            $("#lstUserLevels li").removeClass("active");
            $($("#lstUserLevels li")[me.Datas.Levels.Index]).addClass("active");
            var aTables = {
                Users: Init.Path.UserManage_Users,
                Roles: Init.Path.UserManage_Roles,
            };
            var aPs = { RoleID: me.Datas.Levels.Index };
            Ac.acGetDs(aTables, aPs, function (aRes) {
                me.Datas.Users = aRes.Datas.Users;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Users });
                hhls.fillElement("#tBodyUsers", aHtml);
                me.Datas.UserRoles = aRes.Datas.Roles;
                me.Datas.UserRoles.splice(0, 0, { F_ID: "0", F_Caption: "所有用户" });
                me.RefreshRole(me.Datas.UserRoles, "#cmbRoles");
                //var aInfo = [{ F_ID: 0, F_Caption: "所有用户" }];
                //$.merge(aInfo, me.Datas.UserRoles);
                //me.RefreshDict(aInfo, "#cmbRoles");
            });
        }
        catch (e) { ; }
    },
    RefreshRole: function (aInfo, aElement) {
        var me = OperatorManage;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_ID + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (cer) {; }
    },
    RefreshDict: function (aInfo, aElement) {
        var me = UserManage;
        try {
            var aStr = "";
            if (aInfo.length > 0) {
                for (i in aInfo) {
                    aStr += '<option value="' + aInfo[i].F_ID + '">' + aInfo[i].F_Caption + '</option>';
                }
                hhls.fillElement(aElement, aStr);
            }
        }
        catch (cer) {; }
    },
    OnPickRoles: function () {
        var me = UserManage;
        try {
            me.Datas.Levels.Index = $("#cmbRoles").val();
            var aPs = { RoleID: me.Datas.Levels.Index };
            Ac.acGetTable(Init.Path.UserManage_Users, aPs, function (aRes) {
                me.Datas.Users = aRes.Datas;
                var aHtml = bt(me.Tpls.tplTableItem.C, { tplData: me.Datas.Users });
                hhls.fillElement("#tBodyUsers", aHtml);
            });
        }
        catch (e) { ; }
    },
    doSetDictAuth: function (aIndex) {
        var me = UserManage;
        try {
            var aInfo = { UserID: me.Datas.Users[aIndex].F_ID };
            Ac.acGetTable(Init.Path.UserManage_DictAuth, aInfo, function (aRes) {
                if (aRes.State == 1) {
                    var aAuths = aRes.Datas;
                    var aHtml = bt(me.Tpls.tplDictAuth.C, { tplData: aAuths });
                    var aDlg = hhls.GetModalDlg("#dlgDictAuth", aHtml, function () {
                        var aDictItems = $(".DictItem");
                        $.each(aDictItems, function (aIndex, aItem) {
                            var aDict = aAuths[aIndex];
                            $(aItem).unbind('click').bind('click', function (e) {
                                var aPs = { UserID: aInfo.UserID, DictID: $(e.target).attr("dataKey") };
                                var aChecked = e.target.checked;
                                var aAction = aChecked ? "UserManage_addDictAuth" : "UserManage_removeDictAuth";
                                Common.doUserAction(aAction, aPs, function (aRes) {
                                    //if (aRes.State == 1) { } else {
                                    //    alert("选择失败！");
                                    //}
                                })
                            });
                            if (aDict.F_Chk == 1) {
                                aItem.checked = "checked";
                            }
                        });
                    });
                    aDlg.modal('show');
                }
            });
        }
        catch (e) {; }
    },
    doSetPwd: function (aIndex) {
        var me = UserManage;
        try {
            var aPs = { ID: me.Datas.Users[aIndex].F_ID }; 
            Common.doUserAction("UserManage_setPwd", aPs, function (aRes) {
                if (aRes.State == 1) {
                    Init.Web_Toast("重置成功", 1);
                } else {
                    alert("重置失败！");
                }
            })
        }
        catch (e) {; }
    },
    doShowDlg: function (aIndex) {
        var me = UserManage;
        try {
            me.Datas.PostID = aIndex < 0 ? 0 : me.Datas.Users[aIndex].F_ID;
            var aID = "dlgUserManage";
            var onShow = function (e) {
                if (me.Datas.PostID > 0) {
                    var aInfo = me.Datas.Users[aIndex];
                    $("#txtCode").val(aInfo.F_Code);
                    $("#txtCaption").val(aInfo.F_Caption);
                    $("#txtTel").val(aInfo.F_Tel);
                    $("#txtMail").val(aInfo.F_Mail);
                    $("#txtDesc").val(aInfo.F_Desc);
                    me.RefreshDict(me.Datas.UserRoles, "#cmbRole");
                    $("#cmbRole").val(aInfo.F_RoleID);
                } else {
                    me.RefreshDict(me.Datas.UserRoles, "#cmbRole"); 
                }
            };
            var onHide = function (e) {
                //hhls.removeElement("#" + aID);
                me.RefreshTable();
            };
            var aDlg = $("#" + aID).unbind("hidden.bs.modal").bind("hidden.bs.modal", onHide).unbind("shown.bs.modal").bind("shown.bs.modal", onShow);
            aDlg.modal("show");
        }
        catch (e) { ; }
    },
    doPost: function () {
        var me = UserManage;
        try {
            var aPath = me.Datas.PostID == 0 ? Init.Path.UserManage_New : Init.Path.UserManage_Edit;
            var aPs = {
                Code: $("#txtCode").val(),
                Caption: $("#txtCaption").val(),
                Tel: $("#txtTel").val(),
                Mail: $("#txtMail").val(),
                Desc: $("#txtDesc").val(),
                RoleID: $("#cmbRole").val(),
                ID: me.Datas.PostID
            };
            Ac.acExecuteSql(aPath, aPs, function (aRes) {
                if (aRes.State == 1) {
                    $("#dlgUserManage").modal("toggle");
                }
                else {
                    alert("提交失败！");
                }
            });
        }
        catch (e) { ; }
    },
    doDelete: function (aIndex) {
        var me = UserManage; 
        try {
            var aFlag = window.confirm("是否确定要删除该用户账号？");
            if (aFlag) {
                var aPs = { ID: me.Datas.Users[aIndex].F_ID };
                Ac.acExecuteSql(Init.Path.UserManage_Delete, aPs, function (aRes) {
                    if (aRes.State == 1) {
                        //me.RefreshTable();
                        $(".tr" + aIndex).css("display", "none");
                    }
                    else {
                        alert("删除失败！");
                    }
                });
            }
        }
        catch (e) { ; }
    }
};
